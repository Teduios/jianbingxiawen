//
//  XTAnimator.h
//  实战项目20151205
//
//  Created by Shaw on 15/12/16.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XTAnimator : UIView
singleton_interface(XTAnimator)
- (void)animateWithImages:(NSArray<UIImage *> *)allImages onImageView:(UIImageView *)imageView inDuration:(NSTimeInterval)duration;
@end
