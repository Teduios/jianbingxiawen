//
//  XTAnimator.m
//  实战项目20151205
//
//  Created by Shaw on 15/12/16.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "XTAnimator.h"

@implementation XTAnimator

singleton_implementation(XTAnimator)

- (void)animateWithImages:(NSArray<UIImage *> *)allImages onImageView:(UIImageView *)imageView inDuration:(NSTimeInterval)duration
{
    [imageView setAnimationImages:allImages];

    imageView.animationRepeatCount = 1;

    imageView.animationDuration = duration;
    [imageView startAnimating];
  
    [imageView performSelector:@selector(setAnimationImages:) withObject:nil afterDelay:imageView.animationDuration];
}

@end
