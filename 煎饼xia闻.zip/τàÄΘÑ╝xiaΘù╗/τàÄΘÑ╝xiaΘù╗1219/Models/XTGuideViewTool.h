//
//  XTGuideViewTool.h
//  实战项目20151205
//
//  Created by tarena on 15/12/18.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XTGuideViewTool : NSObject

@property (nonatomic, strong) UIView *guideImageView;

+ (instancetype)showGuideView;
- (instancetype)initShow;

- (void)closeGuideView;
@end
