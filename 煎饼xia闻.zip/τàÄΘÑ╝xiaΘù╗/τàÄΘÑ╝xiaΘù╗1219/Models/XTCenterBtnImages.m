//
//  XTCenterBtnImages.m
//  实战项目20151205
//
//  Created by tarena on 15/12/16.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "XTCenterBtnImages.h"

@implementation XTCenterBtnImages
singleton_implementation(XTCenterBtnImages)

- (NSArray *)allImages
{
    if (!_allImages) {
        _allImages = @[[UIImage imageNamed:@"news1"],[UIImage imageNamed:@"news2"],[UIImage imageNamed:@"news3"],[UIImage imageNamed:@"news4"],[UIImage imageNamed:@"news5"],[UIImage imageNamed:@"news6"]];
    }
    return _allImages;
}

+ (NSArray *)traversalArray:(NSArray *)array withClockwise:(BOOL)clockwise
{
    if (clockwise) {
        return array;
    } else {
        NSMutableArray *mutableArray = [NSMutableArray array];
        for (int i = (int)array.count; i > 0; i--) {
            id obj = array[i-1];
            [mutableArray addObject:obj];
        }
        return [mutableArray copy];
    }
}

@end
