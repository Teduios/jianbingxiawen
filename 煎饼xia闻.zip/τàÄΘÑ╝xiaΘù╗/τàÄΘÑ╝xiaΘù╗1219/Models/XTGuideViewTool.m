//
//  XTGuideViewTool.m
//  实战项目20151205
//
//  Created by tarena on 15/12/18.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "XTGuideViewTool.h"
#import <UIKit/UIKit.h>

@interface XTGuideViewTool ()

@end


@implementation XTGuideViewTool



+ (instancetype)showGuideView
{
     return [[XTGuideViewTool alloc] initShow];
}

- (instancetype)initShow
{
    self = [super init];
    if (self) {
        if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"appOpenCount"] integerValue] != 1) {
            return nil;
        }
        if ([[NSUserDefaults standardUserDefaults] boolForKey:@"isConstellationFirstOpen"]) {
            return nil;
        }
        UIView *view = [[UIApplication sharedApplication].windows lastObject];
        UIView *guideView = [UIView new];
        guideView.frame = view.bounds;
        guideView.backgroundColor = [UIColor colorWithRed:.2f green:.2f blue:.2f alpha:.6f];
        [view addSubview:guideView];
        view.userInteractionEnabled = YES;
        guideView.userInteractionEnabled = YES;
        self.guideImageView = guideView;
        UITapGestureRecognizer *exitGest = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(closeGuideView)];
        [guideView addGestureRecognizer:exitGest];
    }
    return self;
}

- (void)closeGuideView
{
    self.guideImageView.hidden = YES;
}
@end
