//
//  AppDelegate.m
//  实战项目20151205
//
//  Created by tarena on 15/12/5.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "AppDelegate.h"
#import "MainTabBarViewController.h"
#import "WelcomeViewController.h"



@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen]bounds]];
    
    if ([[[NSUserDefaults standardUserDefaults] valueForKey:@"appOpenCount"] integerValue] != 0) {
        MainTabBarViewController *mainTabBarVC = [MainTabBarViewController new];
        self.window.rootViewController = mainTabBarVC;
        self.window.backgroundColor = [UIColor whiteColor];
    } else {
        WelcomeViewController *welcomeVC = [WelcomeViewController new];
        self.window.rootViewController = welcomeVC;
    }
    
    
    
    [self.window makeKeyAndVisible];

    UIApplicationShortcutIcon *icon1 = [UIApplicationShortcutIcon iconWithType:UIApplicationShortcutIconTypeCloud];
    UIApplicationShortcutItem *item1 = [[UIApplicationShortcutItem alloc] initWithType:@"item1" localizedTitle:@"天气查询" localizedSubtitle:nil icon:icon1 userInfo:nil];
  
    UIApplicationShortcutIcon *icon2 = [UIApplicationShortcutIcon iconWithTemplateImageName:@"constellation_hl"];
    UIApplicationShortcutItem *item2 = [[UIApplicationShortcutItem alloc] initWithType:@"item2" localizedTitle:@"星座运程" localizedSubtitle:nil icon:icon2 userInfo:nil];
    
    UIApplicationShortcutIcon *icon3 = [UIApplicationShortcutIcon iconWithType:UIApplicationShortcutIconTypeLove];
    UIApplicationShortcutItem *item3= [[UIApplicationShortcutItem alloc] initWithType:@"item3" localizedTitle:@"实时新闻" localizedSubtitle:nil icon:icon3 userInfo:nil];
    
    UIApplicationShortcutIcon *icon4 = [UIApplicationShortcutIcon iconWithType:UIApplicationShortcutIconTypeSearch];
    UIApplicationShortcutItem *item4 = [[UIApplicationShortcutItem alloc] initWithType:@"item4" localizedTitle:@"快递查询" localizedSubtitle:nil icon:icon4 userInfo:nil];

    if ([[UIDevice currentDevice].systemVersion doubleValue] > 9.0) {
        
        application.shortcutItems = @[item4,item3,item2,item1];
    }

    return YES;
    
}


- (void)application:(UIApplication *)application performActionForShortcutItem:(UIApplicationShortcutItem *)shortcutItem completionHandler:(void (^)(BOOL))completionHandler {
    
    if ([shortcutItem.type isEqualToString:@"item1"])
    {
        MainTabBarViewController *mainVC = [MainTabBarViewController sharedMainTabBarViewController];
        mainVC.selectedIndex = 0;
        
    } else if ([shortcutItem.type isEqualToString:@"item2"]) {
        
        MainTabBarViewController *mainVC = [MainTabBarViewController sharedMainTabBarViewController];
        mainVC.selectedIndex = 1;

    } else if ([shortcutItem.type isEqualToString:@"item3"]) {
        MainTabBarViewController *mainVC = [MainTabBarViewController sharedMainTabBarViewController];
        mainVC.selectedIndex = 2;
    } else {
        MainTabBarViewController *mainVC = [MainTabBarViewController sharedMainTabBarViewController];
        mainVC.selectedIndex = 3;
    }
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
