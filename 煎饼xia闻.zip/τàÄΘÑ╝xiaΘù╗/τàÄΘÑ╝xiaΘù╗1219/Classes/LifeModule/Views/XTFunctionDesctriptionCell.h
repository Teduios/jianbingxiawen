//
//  XTFunctionDesctriptionCell.h
//  实战项目20151205
//
//  Created by Shaw on 15/12/8.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XTFunctionDesctriptionCell : UITableViewCell

@property (strong, nonatomic) NSString *title;
@property (nonatomic, strong) UILabel *functionDesctriptionLabel;

- (instancetype)initWithTitle:(NSString *)title andreuseIdentifier:(NSString *)reuseIdentifier;

@end
