//
//  XTPickerViewCell.m
//  实战项目20151205
//
//  Created by tarena on 15/12/8.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "XTPickerViewCell.h"
#import "XTRequestAndParseTool.h"
#import "XTExpressCompanyResult.h"

@interface XTPickerViewCell () <UIPickerViewDataSource, UIPickerViewDelegate>
@property (nonatomic, strong) NSArray *allExpressCompany;
@property (nonatomic, strong) UIPickerView *pickerView;
@property (nonatomic, strong) NSDictionary *allExpressCompanyDic;
@end

@implementation XTPickerViewCell

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super init];
    if (self) {
        UIPickerView *pickerView = [[UIPickerView alloc] init];
        pickerView.delegate = self;
        pickerView.dataSource = self;
        pickerView.tintColor = [UIColor blackColor];
        self.pickerView = pickerView;
        [self.contentView addSubview:pickerView];
        [pickerView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(self.contentView).insets(UIEdgeInsetsMake(5, 30, 5, 30));
        }];
        self.backgroundColor = [UIColor clearColor];
        self.selectedExpressCode = [self.allExpressCompanyDic valueForKey:[self.allExpressCompany firstObject]];
    }
    return self;
}

- (NSDictionary *)allExpressCompanyDic {
    if (!_allExpressCompanyDic) {
        
        NSString *bundlePath = [[NSBundle mainBundle] pathForResource:@"Battercake" ofType:@"bundle"];
        NSString *plistPath = [[NSBundle bundleWithPath:bundlePath] pathForResource:@"ExpressCo" ofType:@"plist"];
        _allExpressCompanyDic = [NSDictionary dictionaryWithContentsOfFile:plistPath];
    }
    return _allExpressCompanyDic;
}
- (NSArray *)allExpressCompany
{
    
    if (!_allExpressCompany) {
        NSString *bundlePath = [[NSBundle mainBundle] pathForResource:@"Battercake" ofType:@"bundle"];
        NSString *plistPath = [[NSBundle bundleWithPath:bundlePath] pathForResource:@"ExpressCoName" ofType:@"plist"];
        _allExpressCompany = [NSArray arrayWithContentsOfFile:plistPath];
    }
    return _allExpressCompany;
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return self.allExpressCompany.count;
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    
    
    self.selectedExpressCode = [self.allExpressCompanyDic valueForKey:self.allExpressCompany[row]] ;
    [self.delegate expressCompanyCell:self didSelectedExpressCompany:self.selectedExpressCode withCoName:self.allExpressCompany[row]];
    
}

- (UIView *)pickerView:(UIPickerView *)pickerView
            viewForRow:(NSInteger)row
          forComponent:(NSInteger)component
           reusingView:(UIView *)view {
    
    UILabel *pickerLabel = (UILabel *)view;
    
    if (pickerLabel == nil) {
        CGRect frame = CGRectMake(0.0, 0.0, SCREEN_WIDTH, 20);
        pickerLabel = [[UILabel alloc] initWithFrame:frame];
        [pickerLabel setTextAlignment:NSTextAlignmentCenter];
        [pickerLabel setBackgroundColor:[UIColor clearColor]];
        if (CURRENT_DEVICE == 5) {
            [pickerLabel setFont:[UIFont systemFontOfSize:20]];
        } else if (CURRENT_DEVICE == 6) {
            
            [pickerLabel setFont:[UIFont systemFontOfSize:23]];
        } else if (CURRENT_DEVICE == 7) {
            [pickerLabel setFont:[UIFont systemFontOfSize:25]];
        } else {
            [pickerLabel setFont:[UIFont systemFontOfSize:18]];
        }
        

        [pickerLabel setTextColor:[UIColor whiteColor]];
    }
    
    [pickerLabel setText:[self.allExpressCompany objectAtIndex:row]];
    
    return pickerLabel;
    
}



@end
