//
//  XTFunctionDesctriptionCell.m
//  实战项目20151205
//
//  Created by Shaw on 15/12/8.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "XTFunctionDesctriptionCell.h"

@implementation XTFunctionDesctriptionCell

- (instancetype)initWithTitle:(NSString *)title andreuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super init];
    if (self) {
        self.title = title;
        UILabel *functionDesctriptionLabel = [UILabel new];
        functionDesctriptionLabel.text = self.title;
        if (CURRENT_DEVICE == 5) {
            functionDesctriptionLabel.font = [UIFont systemFontOfSize:20.f];
        } else if (CURRENT_DEVICE == 6){
            
            functionDesctriptionLabel.font = [UIFont systemFontOfSize:28.f];
        } else if (CURRENT_DEVICE == 7) {
            functionDesctriptionLabel.font = [UIFont systemFontOfSize:30.f];
        } else {
            functionDesctriptionLabel.font = [UIFont systemFontOfSize:18.f];
        }
        functionDesctriptionLabel.textColor = [UIColor whiteColor];
        self.backgroundColor = [UIColor clearColor];
        
        [self.contentView addSubview:functionDesctriptionLabel];
        [functionDesctriptionLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(self.contentView).insets(UIEdgeInsetsMake(0, 5, 0, -5));
        }];
        self.functionDesctriptionLabel = functionDesctriptionLabel;
    }
    return self;
}


@end
