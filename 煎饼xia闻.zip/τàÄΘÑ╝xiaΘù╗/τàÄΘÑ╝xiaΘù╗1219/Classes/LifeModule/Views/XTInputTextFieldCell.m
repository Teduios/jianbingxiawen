//
//  XTInputTextFieldCell.m
//  实战项目20151205
//
//  Created by tarena on 15/12/9.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "XTInputTextFieldCell.h"
#import "INSSearchBar.h"

#define INPUTBARRECT CGRectMake(35.0, 0.0, CGRectGetWidth(self.contentView.bounds) - 40.0, 35.0)

@interface XTInputTextFieldCell () <INSSearchBarDelegate>

@property (nonatomic, strong) INSSearchBar *inputBar;

@end

@implementation XTInputTextFieldCell

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super init];
    if (self) {
        UIView *view = [[UIView alloc] init];
        [self.contentView addSubview:view];
        [view mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(self.contentView).insets(UIEdgeInsetsMake(5, 0, 5, 0));
            if (CURRENT_DEVICE == 5) {
                make.height.equalTo(@30);
            } else if (CURRENT_DEVICE == 6) {
                make.height.equalTo(@33);
            } else if (CURRENT_DEVICE == 7) {
                make.height.equalTo(@35);
            } else {
                make.height.equalTo(@28);
            }
            
        }];
        view.backgroundColor = [UIColor clearColor];
        
        self.inputBar = [[INSSearchBar alloc] initWithFrame:INPUTBARRECT];
        self.inputBar.tag = 100;
        [view addSubview:self.inputBar];
        self.inputBar.backgroundColor = [UIColor clearColor];
        
        [self.inputBar mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(view).insets(UIEdgeInsetsMake(0, 35, 0, 70));
        }];
        self.inputTextField = self.inputBar.searchField;
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];

        [button setTitle:@"搜索" forState:UIControlStateNormal];
        button.titleLabel.textColor = [UIColor whiteColor];
        [view addSubview:button];

        [button mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(view).offset(5);
            make.bottom.equalTo(view).offset(-5);
            make.left.equalTo(self.inputBar.mas_right).offset(10);
        }];
        button.backgroundColor = [UIColor clearColor];
        [button addTarget:self action:@selector(clickBtn) forControlEvents:UIControlEventTouchUpInside];
        
    }
    self.backgroundColor = [UIColor clearColor];
    return self;
}

- (void)clickBtn
{
    [self.delegate didClickedDoneBtn];
    
}



#pragma mark - search bar delegate
- (CGRect)destinationFrameForSearchBar:(INSSearchBar *)searchBar
{
    return INPUTBARRECT;
}

- (void)searchBar:(INSSearchBar *)searchBar willStartTransitioningToState:(INSSearchBarState)destinationState
{
    
}

- (void)searchBar:(INSSearchBar *)searchBar didEndTransitioningFromState:(INSSearchBarState)previousState
{

    // Do whatever you deem necessary.
}

- (void)searchBarDidTapReturn:(INSSearchBar *)searchBar
{

    // Do whatever you deem necessary.
    // Access the text from the search bar like searchBar.searchField.text
}

- (void)searchBarTextDidChange:(INSSearchBar *)searchBar
{

    // Do whatever you deem necessary.
    // Access the text from the search bar like searchBar.searchField.text
}

@end
