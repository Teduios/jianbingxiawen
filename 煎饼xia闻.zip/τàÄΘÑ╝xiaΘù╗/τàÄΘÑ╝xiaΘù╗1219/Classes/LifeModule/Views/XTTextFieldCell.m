//
//  XTTextFieldCell.m
//  实战项目20151205
//
//  Created by tarena on 15/12/8.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "XTTextFieldCell.h"

@interface XTTextFieldCell () <UITextFieldDelegate>

@end

@implementation XTTextFieldCell

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super init];
    if (self) {
        self.backgroundColor = [UIColor clearColor];

        UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"BackgroundGate"]];
        [self.contentView addSubview:imageView];
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(self.contentView).insets(UIEdgeInsetsMake(0, 30, 0, 30));
            if (CURRENT_DEVICE == 5) {
                make.height.equalTo(@80);
            } else if (CURRENT_DEVICE == 6){
                
                make.height.equalTo(@90);
            } else if (CURRENT_DEVICE == 7) {
                make.height.equalTo(@100);
            } else {
                make.height.equalTo(@60);
            }
        }];
        imageView.userInteractionEnabled = YES;
        UITextField *textField = [[UITextField alloc] init];
        textField.backgroundColor = [UIColor clearColor];
        
        [imageView addSubview:textField];
        [textField mas_makeConstraints:^(MASConstraintMaker *make) {
            if (CURRENT_DEVICE == 5) {
                make.edges.equalTo(imageView).insets(UIEdgeInsetsMake(2, 5, 42, 5));
                make.height.equalTo(@36);
            } else if (CURRENT_DEVICE == 6){
                
                make.edges.equalTo(imageView).insets(UIEdgeInsetsMake(3.5, 5, 47.5, 5));
                make.height.equalTo(@38);
            } else if (CURRENT_DEVICE == 7) {
                make.edges.equalTo(imageView).insets(UIEdgeInsetsMake(5, 5, 55, 5));
                make.height.equalTo(@40);
            } else {
                make.edges.equalTo(imageView).insets(UIEdgeInsetsMake(2, 5, 32, 5));
                make.height.equalTo(@26);
            }
        }];
        
        
        if (CURRENT_DEVICE == 5) {
            textField.placeholder = @"                 请输入运单号";
        } else if (CURRENT_DEVICE == 6) {
            textField.placeholder = @"                       请输入运单号";
        } else if (CURRENT_DEVICE == 7) {
            textField.placeholder = @"                           请输入运单号";
        } else {
            textField.placeholder = @"                 请输入运单号";
        }
        textField.borderStyle = UITextBorderStyleNone;
        textField.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
        textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        self.textField = textField;
        
        UIButton *button = [[UIButton alloc] init];
        [imageView addSubview:button];
        [button mas_makeConstraints:^(MASConstraintMaker *make) {
            if (CURRENT_DEVICE == 5) {
                make.edges.equalTo(imageView).insets(UIEdgeInsetsMake(42, 5, 2, 5));
                make.height.equalTo(@36);
            } else if (CURRENT_DEVICE == 6){
                make.edges.equalTo(imageView).insets(UIEdgeInsetsMake(47.5, 5, 3.5, 5));
                make.height.equalTo(@38);
            } else if (CURRENT_DEVICE == 7) {
                make.edges.equalTo(imageView).insets(UIEdgeInsetsMake(55, 5, 5, 5));
                make.height.equalTo(@40);
            } else {
                make.edges.equalTo(imageView).insets(UIEdgeInsetsMake(32, 5, 2, 5));
                make.height.equalTo(@26);
            }
            
        }];
        [button setTitle:@"请选择快递公司" forState:UIControlStateNormal];
        [button addTarget:self action:@selector(selectExpressCompanyBtnClicked) forControlEvents:UIControlEventTouchUpInside];
        self.selBtn = button;
        
    }
    return self;
}

- (void)selectExpressCompanyBtnClicked
{
    
    [self.delegate didClickedSelectExpressCompanyBtn];
}




@end
