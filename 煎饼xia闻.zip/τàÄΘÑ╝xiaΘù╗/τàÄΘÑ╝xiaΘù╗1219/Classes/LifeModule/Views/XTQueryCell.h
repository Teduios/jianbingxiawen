//
//  XTQueryCell.h
//  实战项目20151205
//
//  Created by Shaw on 15/12/8.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XTQueryCell;

@protocol XTQueryCellDelegate <NSObject>

- (void)didClickedQueryBtn;

@end
@interface XTQueryCell : UITableViewCell

@property (nonatomic, weak) id<XTQueryCellDelegate> delegate;

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier;

@end
