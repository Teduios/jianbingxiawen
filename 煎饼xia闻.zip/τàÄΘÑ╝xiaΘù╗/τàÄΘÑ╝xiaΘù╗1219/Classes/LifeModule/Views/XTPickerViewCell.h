//
//  XTPickerViewCell.h
//  实战项目20151205
//
//  Created by tarena on 15/12/8.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XTPickerViewCell;

@protocol XTPickerViewCellDelegate <NSObject>

- (void)expressCompanyCell:(XTPickerViewCell *)cell didSelectedExpressCompany:(NSString *)selectedExpressCode withCoName:(NSString *)coName;
@end


@interface XTPickerViewCell : UITableViewCell

@property (nonatomic, strong) NSString *selectedExpressCode;

@property (nonatomic, weak) id<XTPickerViewCellDelegate> delegate;

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier;


@end
