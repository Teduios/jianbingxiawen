//
//  XTTextFieldCell.h
//  实战项目20151205
//
//  Created by tarena on 15/12/8.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XTTextFieldCell;

@protocol XTTextFieldCellDelegate <NSObject>

- (void)didClickedSelectExpressCompanyBtn;

@end

@interface XTTextFieldCell : UITableViewCell

@property (nonatomic, weak) id<XTTextFieldCellDelegate> delegate;
@property (nonatomic, strong) UITextField *textField;
@property (nonatomic, strong) UIButton *selBtn;
- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier;


@end
