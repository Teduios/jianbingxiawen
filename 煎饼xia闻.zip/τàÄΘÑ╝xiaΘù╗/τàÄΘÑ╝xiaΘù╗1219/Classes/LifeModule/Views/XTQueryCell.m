//
//  XTQueryCell.m
//  实战项目20151205
//
//  Created by Shaw on 15/12/8.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "XTQueryCell.h"

@implementation XTQueryCell


- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super init];
    if (self) {
        UIButton *button = [[UIButton alloc] init];
        [self.contentView addSubview:button];
        [button mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(self.contentView).insets(UIEdgeInsetsMake(5, 30, 5, 30));
            if (CURRENT_DEVICE == 5) {
                make.height.equalTo(@40);
            } else if (CURRENT_DEVICE == 6){
                make.height.equalTo(@45);
            } else if (CURRENT_DEVICE == 7) {
                make.height.equalTo(@50);
            } else {
                make.height.equalTo(@30);
            }
        }];
        
        UIView *backIV = [UIView new];
        backIV.backgroundColor = [UIColor colorWithWhite:1.f alpha:.5f];
        backIV.layer.masksToBounds = YES;
        backIV.layer.cornerRadius = 5;
        [self.contentView insertSubview:backIV atIndex:0];
        backIV.userInteractionEnabled = YES;
        [backIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.equalTo(button);
        }];
        self.backgroundColor = [UIColor clearColor];
        [button setTitle:@"点击查询运单" forState:UIControlStateNormal];
        [button addTarget:self action:@selector(queryWayBillBtnClicked) forControlEvents:UIControlEventTouchUpInside];
    }
    return self;
}

- (void)queryWayBillBtnClicked
{
    [self.delegate didClickedQueryBtn];
}

@end
