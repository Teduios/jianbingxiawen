//
//  XTWayBillDetailCell.m
//  实战项目20151205
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "XTWayBillDetailCell.h"

@implementation XTWayBillDetailCell

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super init];
    if (self) {
        UILabel *timeLabel = [UILabel new];
        timeLabel.numberOfLines = 1;
        if (CURRENT_DEVICE == 5) {
            timeLabel.font = [UIFont systemFontOfSize:13.f];
        } else {
            
            timeLabel.font = [UIFont systemFontOfSize:16.f];
        }
        [self.contentView addSubview:timeLabel];
        [timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@2);
            make.left.equalTo(@5);
            make.right.equalTo(self.contentView);
            make.height.equalTo(@21);
        }];
        self.timeLabel = timeLabel;
        UILabel *processLabel = [UILabel new];
        processLabel.numberOfLines = 0;
        if (CURRENT_DEVICE == 5) {
            processLabel.font = [UIFont systemFontOfSize:16.f];
        } else if (CURRENT_DEVICE == 6){
            
            processLabel.font = [UIFont systemFontOfSize:18.f];
        } else if (CURRENT_DEVICE == 7) {
            processLabel.font = [UIFont systemFontOfSize:20.f];
        } else {
            processLabel.font = [UIFont systemFontOfSize:14.f];
        }
        [self.contentView addSubview:processLabel];
        [processLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(@20);
            make.right.equalTo(@(-20));
            make.top.equalTo(timeLabel.mas_bottom).offset(5);
            make.bottom.equalTo(self.contentView.mas_bottom).offset(-5);
        }];
        self.processLabel = processLabel;
    }
    return self;
}

@end
