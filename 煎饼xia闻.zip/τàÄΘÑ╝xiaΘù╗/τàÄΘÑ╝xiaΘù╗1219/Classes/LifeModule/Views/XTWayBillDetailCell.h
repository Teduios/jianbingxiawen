//
//  XTWayBillDetailCell.h
//  实战项目20151205
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XTWayBillDetailCell : UITableViewCell

@property (nonatomic, strong) UILabel *timeLabel;
@property (nonatomic, strong) UILabel *processLabel;

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier;

@end
