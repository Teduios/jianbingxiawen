//
//  XTInputTextFieldCell.h
//  实战项目20151205
//
//  Created by tarena on 15/12/9.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XTInputTextFieldCell;

@protocol XTInputTextFieldCellDelegate <NSObject>

- (void)didClickedDoneBtn;

@end

@interface XTInputTextFieldCell : UITableViewCell

@property (nonatomic, weak) id<XTInputTextFieldCellDelegate> delegate;

@property (nonatomic, strong) UITextField *inputTextField;

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier;

@end
