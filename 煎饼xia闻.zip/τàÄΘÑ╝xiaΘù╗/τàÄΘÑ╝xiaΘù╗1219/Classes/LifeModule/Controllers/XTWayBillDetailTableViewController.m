//
//  XTWayBillDetailTableViewController.m
//  实战项目20151205
//
//  Created by tarena on 15/12/11.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "XTWayBillDetailTableViewController.h"
#import "XTFunctionDesctriptionCell.h"
#import "XTWayBillDetailCell.h"
#import "MainTabBarViewController.h"



@interface XTWayBillDetailTableViewController ()
@property (nonatomic, strong) UIImageView *backgroundView;
@end

@implementation XTWayBillDetailTableViewController

-(UIImageView *)backgroundView
{
    if (!_backgroundView) {
        _backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:LIFE_MODULE_BACKGROUND_IMAGE_NAME_DAY]];    }
    return _backgroundView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self configTableView];
}

- (void)configTableView
{
    [self.tableView registerClass:[XTFunctionDesctriptionCell class] forCellReuseIdentifier:@"cell0"];
    self.tabBarController.tabBar.hidden = YES;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [MainTabBarViewController sharedMainTabBarViewController].centerIV.hidden = YES;
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.allowsSelection = NO;
    self.tableView.backgroundView = self.backgroundView;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self shouldChangeTheme];
}
#pragma mark----ChangeTheme
- (void)shouldChangeTheme {
    BOOL status = [FifthViewController sharedFifthViewController].ThemeSwitchStatus;
    if (status) {
        self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
        self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
        self.backgroundView.image = [UIImage imageNamed:LIFE_MODULE_BACKGROUND_IMAGE_NAME_NIGHT];
        [self.view layoutIfNeeded];
    } else {
        self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
        self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
        self.backgroundView.image = [UIImage imageNamed:LIFE_MODULE_BACKGROUND_IMAGE_NAME_DAY];
        [self.view layoutIfNeeded];
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return self.timeArray.count + 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        XTFunctionDesctriptionCell *cell = [[XTFunctionDesctriptionCell alloc] initWithTitle:@"过程信息" andreuseIdentifier:@"cell0"];
        cell.functionDesctriptionLabel.textColor = [UIColor whiteColor];
        cell.backgroundColor = [UIColor clearColor];
        return cell;
    } else {
        XTWayBillDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell1"];
        if (!cell) {
            cell = [[XTWayBillDetailCell alloc] initWithReuseIdentifier:@"cell1"];
        }
        cell.timeLabel.textColor = [UIColor whiteColor];
        cell.processLabel.textColor = [UIColor whiteColor];
        cell.timeLabel.text = self.timeArray[indexPath.row - 1];
        cell.processLabel.text = self.processInfoArray[indexPath.row - 1];
        cell.backgroundColor = [UIColor clearColor];
        return cell;
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewAutomaticDimension;
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [MainTabBarViewController sharedMainTabBarViewController].centerIV.hidden = NO;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end



