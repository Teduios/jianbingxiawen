//
//  FourthViewController.m
//  实战项目20151205
//
//  Created by tarena on 15/12/5.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "FourthViewController.h"
#import "XTRequestAndParseTool.h"
#import "XTPhoneNumberAttribution.h"
#import "XTWayBillQuery.h"
#import "XTTextFieldCell.h"
#import "XTPickerViewCell.h"
#import "XTQueryCell.h"
#import "XTFunctionDesctriptionCell.h"
#import "XTInputTextFieldCell.h"
#import "INSSearchBar.h"
#import "XTWayBillDetailTableViewController.h"
#import "XTExpressCompanyResult.h"



@interface FourthViewController () <UITableViewDelegate, UITableViewDataSource, XTTextFieldCellDelegate, XTQueryCellDelegate, XTInputTextFieldCellDelegate, XTPickerViewCellDelegate>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *allCells;
@property (assign, nonatomic, getter=isForbidSelectExCBtn) BOOL forbidSelectExCBtn;
@property (nonatomic, assign, getter=isClickedSelectExCBtn) BOOL clickedSelectExCBtn;
@property (assign, nonatomic, getter=isFirstClickQueryBtn) BOOL firstClickQueryBtn;

@property (strong, nonatomic) NSString *serviceProvider;
@property (strong, nonatomic) NSString *province;
@property (strong, nonatomic) NSString *city;
@property (strong, nonatomic) NSString *selectedExpressCode;
@property (nonatomic, strong) UIImageView *backgroundView;

@property (nonatomic, strong) XTGuideViewTool *tool;
@end

@implementation FourthViewController
singleton_implementation(FourthViewController)

- (void)viewDidLoad {
    [super viewDidLoad];

    [self configViews];

    [self configGuidView];

    self.firstClickQueryBtn = YES;
    self.clickedSelectExCBtn = NO;
    self.forbidClickQueryBtn = NO;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(packUpPickerViewCell) name:UIKeyboardWillShowNotification object:nil];
    
}
- (void)configGuidView
{
    CGFloat shuRuX = 0;
    CGFloat shuRuY = 0;
    CGFloat shuRuW = 0;
    if (CURRENT_DEVICE == 7) {
        shuRuX = 15;
        shuRuY = SCREEN_HEIGHT/2-100;
        shuRuW = 400;
    } else if (CURRENT_DEVICE == 6) {
        shuRuX = -27;
        shuRuY = SCREEN_HEIGHT/2-85;
        shuRuW = 400;
    } else if (CURRENT_DEVICE == 5){
        shuRuX = -3;
        shuRuY = SCREEN_HEIGHT/2-73;
        shuRuW = 300;
    } else {
        shuRuX = -3;
        shuRuY = SCREEN_HEIGHT/2-73;
        shuRuW = 300;
    }
    XTGuideViewTool *tool = [XTGuideViewTool showGuideView];
    UIImageView *imageView1 = [[UIImageView alloc]initWithFrame:CGRectMake(shuRuX, shuRuY, shuRuW, 225)];
    imageView1.image = [UIImage imageNamed:@"LifeMInputGuide"];
    [tool.guideImageView addSubview:imageView1];
    self.tool = tool;
}

-(UIImageView *)backgroundView
{
    if (!_backgroundView) {
        _backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:LIFE_MODULE_BACKGROUND_IMAGE_NAME_DAY]];
    }
    return _backgroundView;
}


#pragma mark --- 初始化tableView
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [UITableView new];
        _tableView.allowsSelection = NO;
        _tableView.bounces = NO;
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.backgroundView = self.backgroundView;
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        UITapGestureRecognizer *tapGesture = [UITapGestureRecognizer new];
        [tapGesture addTarget:self action:@selector(closeKeyboard)];
        [_tableView addGestureRecognizer:tapGesture];
        
    }
    return _tableView;
}

#pragma mark ---- 收起键盘添加手势响应的方法
- (void)closeKeyboard
{
    [self.view endEditing:YES];
    [self hideInputTextField];
    
    [MBProgressHUD hideAllHUDsForView:self.tableView animated:YES];
}
#pragma mark ---- 配置视图控制器的视图
- (void)configViews
{
    [self.view addSubview:self.tableView];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self.view);
        make.edges.equalTo(self.view);
    }];
    
}


#pragma mark ---- 当视图将要出现时
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden = NO;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(openInputTextField) name:@"inputText" object:nil];
    [self packUpAllCells];
    
    [self shouldChangeTheme];
    
}

#pragma mark----ChangeTheme
- (void)shouldChangeTheme {
    BOOL status = [FifthViewController sharedFifthViewController].ThemeSwitchStatus;
    if (status) {
        self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
        
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];

        self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
        self.backgroundView.image = [UIImage imageNamed:LIFE_MODULE_BACKGROUND_IMAGE_NAME_NIGHT];
        [self.view layoutIfNeeded];
    } else {
        self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
        self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
        self.backgroundView.image = [UIImage imageNamed:LIFE_MODULE_BACKGROUND_IMAGE_NAME_DAY];
        [self.view layoutIfNeeded];
    }
}

#pragma mark ---- 当视图将要消失时
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self packUpAllCells];
    [self hideInputTextField];
    XTTextFieldCell *cell = self.allCells[1];
    cell.textField.text = nil;
    self.selectedExpressCode = nil;
    [cell.selBtn setTitle:@"请选择快递公司" forState:UIControlStateNormal];
}

#pragma mark ---- 隐藏查询手机归属的搜索栏
- (void)hideInputTextField
{
    [self packUpAllCells];
    XTInputTextFieldCell *cell = self.allCells[4];
    INSSearchBar *view = [cell viewWithTag:100];
    [view hideSearchBar:nil];
}

#pragma mark ---- 启动时收起所有的可弹出cell
- (void)packUpAllCells
{
    [self packUpPickerViewCell];
    [self packUpQueryResultCells];
}
#pragma mark ---- 当收到打开手机号码归属查询的textField时的通知后执行的方法
- (void)openInputTextField
{
    [self packUpPickerViewCell];
    [self scrollToRow:4 inSection:0];
}
#pragma mark ---- tableDataSource协议中的方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.allCells.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return self.allCells[indexPath.row];
    
}
#pragma mark ---- 预估tableView的行高
- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewAutomaticDimension;
}

#pragma mark ---- 已经点击了查询快递运单按钮
- (void)didClickedQueryBtn
{
    [self.view endEditing:YES];
    if (self.isForbidClickQueryBtn) {
        return;
    } else {
        self.forbidClickQueryBtn = YES;
        
        [MBProgressHUD hideHUD];
        [MBProgressHUD showMessage:@"正在查询,请稍后..."];
        XTTextFieldCell *cell = self.allCells[1];
        if (cell.textField.text.length == 0) {
            [MBProgressHUD hideHUD];
            [MBProgressHUD showError:@"请输入运单号"];
            self.forbidClickQueryBtn = NO;
        } else {
            if (!self.selectedExpressCode) {
                [MBProgressHUD hideHUD];
                [MBProgressHUD showError:@"请选择快递公司"];
                self.forbidClickQueryBtn = NO;
                return;
            }
            
            [XTRequestAndParseTool requestWaybillQueryWithExpresscode:self.selectedExpressCode andBillNumber:cell.textField.text parsedCompletion:^(id obj) {
                
                cell.textField.text = nil;
                XTWayBillQuery *wayBill = (XTWayBillQuery *)obj;
                
                [MBProgressHUD hideHUD];
                
                XTWayBillDetailTableViewController *wayBillDetailTVC = [XTWayBillDetailTableViewController new];
                

                NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"ExpressCo" ofType:@"plist"];
                NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile:plistPath];
                NSArray *allKeys = [dict allKeys];
                for (NSString *key in allKeys) {
                    if ([self.selectedExpressCode isEqualToString:[dict objectForKey:key]]) {
                        wayBillDetailTVC.title = key;
                    }
                }
                
                wayBillDetailTVC.processInfoArray = wayBill.processInfoArray;
                wayBillDetailTVC.timeArray = wayBill.timeArray;
                [self.navigationController pushViewController:wayBillDetailTVC animated:YES];
                
            }];
            
        }
        [self packUpPickerViewCell];
    }
}


#pragma mark ---- 已经点击了选择快递公司按钮
- (void)didClickedSelectExpressCompanyBtn
{
    [self.view endEditing:YES];
    
    self.clickedSelectExCBtn = !self.clickedSelectExCBtn;
    
    if (!self.isClickedSelectExCBtn) {
        [self packUpPickerViewCell];
        return;
    }
    
    if (!self.forbidSelectExCBtn) {
        XTPickerViewCell *cell3 = [[XTPickerViewCell alloc] initWithReuseIdentifier:@"cell3"];
        cell3.delegate = self;
        [self.allCells insertObject:cell3 atIndex:2];
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:2 inSection:0];
        [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationTop];
    }
    self.forbidSelectExCBtn = YES;
    if (self.selectedExpressCode == nil) {
        if ([self.allCells[2] isKindOfClass:[XTPickerViewCell class]]) {
            XTPickerViewCell *cell = self.allCells[2];
            self.selectedExpressCode = cell.selectedExpressCode;
        }
    }
    
}
#pragma mark ---- pickerView的值发生了改变
- (void)expressCompanyCell:(XTPickerViewCell *)cell didSelectedExpressCompany:(NSString *)selectedExpressCode withCoName:(NSString *)coName
{
    self.selectedExpressCode = cell.selectedExpressCode;

    XTTextFieldCell *cell1 = self.allCells[1];
    
    [cell1.selBtn setTitle:coName forState:UIControlStateNormal];
}

#pragma mark ---- 展示查询手机归属的结果
- (void)showQueryResult
{
    
    UITableViewCell *cell6 = nil;
    UITableViewCell *cell7 = nil;
    UITableViewCell *cell8 = nil;
    if (self.firstClickQueryBtn) {
        cell6 = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"6"];
        cell6.textLabel.text = self.serviceProvider;
        cell7 = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"6"];
        cell7.textLabel.text = self.province;
        cell8 = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"6"];
        cell8.textLabel.text = self.city;
        cell6.textLabel.textColor = [UIColor whiteColor];
        cell7.textLabel.textColor = [UIColor whiteColor];
        cell8.textLabel.textColor = [UIColor whiteColor];
        cell6.backgroundColor = [UIColor clearColor];
        cell7.backgroundColor = [UIColor clearColor];
        cell8.backgroundColor = [UIColor clearColor];
        [self.allCells insertObject:cell6 atIndex:5];
        [self.allCells insertObject:cell7 atIndex:6];
        [self.allCells insertObject:cell8 atIndex:7];
        NSIndexPath *indexPath1 = [NSIndexPath indexPathForRow:5 inSection:0];
        NSIndexPath *indexPath2 = [NSIndexPath indexPathForRow:6 inSection:0];
        NSIndexPath *indexPath3 = [NSIndexPath indexPathForRow:7 inSection:0];
        [self.tableView insertRowsAtIndexPaths:@[indexPath1, indexPath2, indexPath3] withRowAnimation:UITableViewRowAnimationTop];
        
    } else {
        cell6 = self.allCells[5];
        cell7 = self.allCells[6];
        cell8 = self.allCells[7];
        cell6.textLabel.text = self.serviceProvider;
        cell7.textLabel.text = self.province;
        cell8.textLabel.text = self.city;
        
    }
    self.firstClickQueryBtn = NO;
    
}
#pragma mark ---- 收起PickerViewCell
- (void)packUpPickerViewCell
{
    if ([self.allCells[2] isKindOfClass:[XTPickerViewCell class]]) {
        [self.allCells removeObjectAtIndex:2];
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:2 inSection:0];
        [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationTop];
    }
    self.forbidSelectExCBtn = NO;
}
#pragma mark --- 收起手机号归属查询结果的3个cell
- (void)packUpQueryResultCells
{
    [self packUpPickerViewCell];
    for (int i = 0; i < 3; i++) {
        if (self.allCells.count > 5 && ([self.allCells[5] isMemberOfClass:[UITableViewCell class]])) {
            [self.allCells removeObjectAtIndex:5];
            if (i == 2) {
                NSIndexPath *indexPath1 = [NSIndexPath indexPathForRow:5 inSection:0];
                NSIndexPath *indexPath2 = [NSIndexPath indexPathForRow:6 inSection:0];
                NSIndexPath *indexPath3 = [NSIndexPath indexPathForRow:7 inSection:0];
                [self.tableView deleteRowsAtIndexPaths:@[indexPath1, indexPath2, indexPath3] withRowAnimation:UITableViewRowAnimationTop];
            }
        }
    }
    self.firstClickQueryBtn = YES;
}
#pragma mark ---- 已经点击了确认查询手机号码归属按钮
- (void)didClickedDoneBtn
{
    [MBProgressHUD hideHUD];
    [MBProgressHUD showMessage:@"正在查询,请稍后..."];
    XTInputTextFieldCell *cell = nil;
    for (id obj in self.allCells) {
        if ([obj isKindOfClass:[XTInputTextFieldCell class]]) {
            cell = obj;
        }
    }
    if (cell.inputTextField.text.length > 11 || cell.inputTextField.text.length < 7) {
        [MBProgressHUD hideHUD];
        [MBProgressHUD showError:@"请正确输入要查询的手机号"];
    } else {
        [XTRequestAndParseTool requestPhoneNumberAttributionWithPhoneNumber:cell.inputTextField.text parsedCompletion:^(id obj) {
            [MBProgressHUD hideHUD];
            [self packUpPickerViewCell];
            XTPhoneNumberAttribution *phoneNumAtt = (XTPhoneNumberAttribution *)obj;
            self.serviceProvider = @"运营商:";
            self.province = @"省份:";
            self.city = @"城市:";
            self.serviceProvider = [self.serviceProvider stringByAppendingString:phoneNumAtt.company];
            self.province = [self.province stringByAppendingString:phoneNumAtt.province];
            self.city = [self.city stringByAppendingString:phoneNumAtt.city];
            [self showQueryResult];
        }];
        
    }
    
}
#pragma mark ---- 初始化所有单元格
- (NSMutableArray *)allCells
{
    if (!_allCells) {
        _allCells = [NSMutableArray array];
        XTFunctionDesctriptionCell *cell0 = [[XTFunctionDesctriptionCell alloc] initWithTitle:@"查询运单" andreuseIdentifier:@"cell0"];
        XTTextFieldCell *cell1 = [[XTTextFieldCell alloc] initWithReuseIdentifier:@"cell1"];
        cell1.delegate = self;
        XTQueryCell *cell2 = [[XTQueryCell alloc] initWithReuseIdentifier:@"cell2"];
        cell2.delegate = self;
        XTFunctionDesctriptionCell *cell4 = [[XTFunctionDesctriptionCell alloc] initWithTitle:@"手机号码归属查询" andreuseIdentifier:@"cell0"];
        XTInputTextFieldCell *cell5 = [[XTInputTextFieldCell alloc] initWithReuseIdentifier:@"cell5"];
        cell5.delegate = self;
        cell5.inputTextField.keyboardType = UIKeyboardTypePhonePad;
        [self.allCells addObject:cell0];
        [self.allCells addObject:cell1];
        [self.allCells addObject:cell2];
        [self.allCells addObject:cell4];
        [self.allCells addObject:cell5];

    }
    return _allCells;
}

#pragma mark ---- 滚动tableView到某个位置
- (void)scrollToRow:(int)row inSection:(int)section
{
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:row inSection:section];
    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:(UITableViewScrollPositionBottom) animated:YES];
}
#pragma mark ---- 当控制器视图已经消失的方法
- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"inputText" object:nil];
    [self packUpAllCells];
    [self closeKeyboard];
    
}



@end
