//
//  XTWayBillDetailTableViewController.h
//  实战项目20151205
//
//  Created by tarena on 15/12/11.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XTWayBillDetailTableViewController : UITableViewController

@property (nonatomic, strong) NSArray *processInfoArray;
@property (nonatomic, strong) NSArray *timeArray;

@end
