//
//  FourthViewController.h
//  实战项目20151205
//
//  Created by tarena on 15/12/5.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface FourthViewController : UIViewController
@property (assign, nonatomic, getter=isForbidClickQueryBtn) BOOL forbidClickQueryBtn;
singleton_interface(FourthViewController)
@end
