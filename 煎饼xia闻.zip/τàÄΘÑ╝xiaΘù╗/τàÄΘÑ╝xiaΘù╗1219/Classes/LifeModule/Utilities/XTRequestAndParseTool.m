//
//  XTPhoneNumberAttributionTool.m
//  实战项目20151205
//
//  Created by tarena on 15/12/7.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "XTRequestAndParseTool.h"
#import "XTPhoneNumberAttribution.h"
#import "XTWayBillQuery.h"
#import "XTExpressCompanyResult.h"
#import "FourthViewController.h"
typedef enum {
    PARSEPHONENUM = 1,
    PARSEWAYBILL,
    PARSEEXPRESSCO
}ParseOptions;

@implementation XTRequestAndParseTool

+ (void)requestPhoneNumberAttributionWithPhoneNumber:(NSString *)phoneNum parsedCompletion:(MyBlock)myblock
{
    NSString *urlStr = PHONE_NUM_ATT_URL;
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"phone"] = phoneNum;
    parameters[@"key"] = PHONE_NUM_ATT_APIKEY;
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager GET:urlStr parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *jsonDic = (NSDictionary *)responseObject;
        if ([jsonDic[@"resultcode"] isEqualToString:@"200"]) {
            XTPhoneNumberAttribution *phoneNumAtt = (XTPhoneNumberAttribution *)[self parseWithJSONDic:jsonDic withParseOptions:PARSEPHONENUM];
            myblock(phoneNumAtt);
        } else {
            [MBProgressHUD hideHUD];
            [MBProgressHUD showError:@"请求失败,请输入正确的手机号"];
        }

    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [MBProgressHUD hideHUD];
        [MBProgressHUD showError:@"请求失败,请检查您的网络连接"];
    }];
    
}


+ (void)requestWaybillQueryWithExpresscode:(NSString *)expresscode andBillNumber:(NSString *)billNum parsedCompletion:(MyBlock)myblock
{
    NSString *urlStr = WAYBILL_QUERY_URL;
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"appkey"] = WAYBILL_QUERY_APIKEY;
    parameters[@"type"] = expresscode;
    parameters[@"number"] = billNum;
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    [manager GET:urlStr parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [FourthViewController sharedFourthViewController].forbidClickQueryBtn = NO;
        NSDictionary *jsonDic = (NSDictionary *)responseObject;
        NSInteger status = [jsonDic[@"status"] integerValue];
        NSString *error;
        switch (status) {
            case 0:
                error = nil;
                break;
            case 205:
                error = @"快递公司不匹配或运单号过期";
                break;
            default:
                error = @"服务器错误";
                break;
        }
        if (error) {
            [MBProgressHUD hideHUD];
            [MBProgressHUD showError:error];
        } else {
            XTWayBillQuery *wayBill = [self parseWithJSONDic:jsonDic withParseOptions:PARSEWAYBILL];
            myblock(wayBill);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [FourthViewController sharedFourthViewController].forbidClickQueryBtn = NO;
        [MBProgressHUD hideHUD];
        [MBProgressHUD showError:@"请求失败"];
    }];
    
}



+ (id)parseWithJSONDic:(NSDictionary *)jsonDic withParseOptions:(ParseOptions)parseOptions
{
    if (parseOptions == PARSEPHONENUM) {
        XTPhoneNumberAttribution *phoneNumAtt = [XTPhoneNumberAttribution new];
        phoneNumAtt.error_code = [jsonDic[@"error_code"] intValue];
        phoneNumAtt.reason = jsonDic[@"reason"];
        phoneNumAtt.province = jsonDic[@"result"][@"province"];
        phoneNumAtt.city = jsonDic[@"result"][@"city"];
        phoneNumAtt.areacode = jsonDic[@"result"][@"areacode"];
        phoneNumAtt.company = jsonDic[@"result"][@"company"];
        return phoneNumAtt;
    } else if (parseOptions == PARSEWAYBILL) {
        XTWayBillQuery *wayBill = [XTWayBillQuery new];
        wayBill.status = jsonDic[@"status"];
        wayBill.msg = jsonDic[@"msg"];
        wayBill.result = jsonDic[@"result"];
        wayBill.list = wayBill.result[@"list"];
        NSMutableArray *mutableProcessInfoArray = [NSMutableArray array];
        NSMutableArray *mutableTimeArray = [NSMutableArray array];
        for (NSDictionary *dic in wayBill.list) {
            [mutableProcessInfoArray addObject:dic[@"status"]];
            [mutableTimeArray addObject:dic[@"time"]];
        }
        wayBill.processInfoArray = [mutableProcessInfoArray copy];
        wayBill.timeArray = [mutableTimeArray copy];
        return wayBill;
    } else {
        XTExpressCompanyResult *expressCo = [XTExpressCompanyResult new];
        expressCo.status = jsonDic[@"status"];
        expressCo.msg = jsonDic[@"msg"];
        expressCo.result = jsonDic[@"result"];
        NSMutableArray *mutableNameArray = [NSMutableArray array];
        NSMutableArray *mutableTypeArray = [NSMutableArray array];
        for (NSDictionary *dic in expressCo.result) {
            [mutableNameArray addObject:dic[@"name"]];
            [mutableTypeArray addObject:dic[@"type"]];
        }
        expressCo.nameArray = [mutableNameArray copy];
        expressCo.typeArray = [mutableTypeArray copy];
        return expressCo;
    }
    
}

+ (void)requestExpressCompanyResultParsedCompletion:(MyBlock)myblock
{
    NSString *urlStr = EXPRESSCO_QUERY_URL;
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"appkey"] = WAYBILL_QUERY_APIKEY;
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    [manager GET:urlStr parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *jsonDic = (NSDictionary *)responseObject;
        NSInteger status = [jsonDic[@"status"] integerValue];
        if (status != 0) {
        } else {
            XTExpressCompanyResult *expressCo = [self parseWithJSONDic:jsonDic withParseOptions:PARSEEXPRESSCO];
            myblock(expressCo);
        }

    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
    }];
}
@end
