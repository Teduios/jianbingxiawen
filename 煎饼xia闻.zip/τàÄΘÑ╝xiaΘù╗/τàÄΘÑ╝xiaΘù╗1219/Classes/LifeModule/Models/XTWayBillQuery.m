//
//  XTWayBillQuery.m
//  实战项目20151205
//
//  Created by tarena on 15/12/7.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "XTWayBillQuery.h"

@implementation XTWayBillQuery
- (void)setNilValueForKey:(NSString *)key{};
@end
