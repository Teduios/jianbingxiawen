//
//  XTWayBillQuery.h
//  实战项目20151205
//
//  Created by tarena on 15/12/7.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XTWayBillQuery : NSObject

@property (nonatomic, strong) NSString *status;
@property (nonatomic, strong) NSString *msg;
@property (nonatomic, strong) NSDictionary *result;
@property (nonatomic, strong) NSArray *list;
@property (nonatomic, strong) NSString *time;
@property (nonatomic, strong) NSString *detailStatus;
@property (nonatomic, strong) NSArray *processInfoArray;
@property (nonatomic, strong) NSArray *timeArray;
@end
