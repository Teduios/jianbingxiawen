//
//  XTPhoneNumberAttribution.h
//  实战项目20151205
//
//  Created by tarena on 15/12/7.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XTPhoneNumberAttribution : NSObject

@property (nonatomic, assign) int error_code;
@property (nonatomic, strong) NSString *reason;
@property (nonatomic, strong) NSString *province;
@property (nonatomic, strong) NSString *city;
@property (nonatomic, strong) NSString *areacode;
@property (nonatomic, strong) NSString *company;

@end
