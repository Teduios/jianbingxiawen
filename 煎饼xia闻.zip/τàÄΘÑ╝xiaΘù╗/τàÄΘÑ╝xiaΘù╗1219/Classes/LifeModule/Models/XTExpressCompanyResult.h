//
//  XTExpressCompanyResult.h
//  实战项目20151205
//
//  Created by tarena on 15/12/17.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XTExpressCompanyResult : NSObject
@property (nonatomic, strong) NSString *status;
@property (nonatomic, strong) NSString *msg;
@property (nonatomic, strong) NSArray *result;
@property (nonatomic, strong) NSArray *nameArray;
@property (nonatomic, strong) NSArray *typeArray;
@end
