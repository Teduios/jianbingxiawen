//
//  XTExpressCompanyResult.m
//  实战项目20151205
//
//  Created by tarena on 15/12/17.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "XTExpressCompanyResult.h"

@implementation XTExpressCompanyResult
- (void)setNilValueForKey:(NSString *)key{};
@end
