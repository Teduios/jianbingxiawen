//
//  MainTabBarViewController.h
//  实战项目20151205
//
//  Created by tarena on 15/12/5.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainTabBarViewController : UITabBarController

singleton_interface(MainTabBarViewController)


@property (nonatomic, strong) UIImageView *centerIV;

@property (nonatomic, assign) NSInteger appOpenCount;

@property (nonatomic, assign) BOOL notFirstStart;
@end
