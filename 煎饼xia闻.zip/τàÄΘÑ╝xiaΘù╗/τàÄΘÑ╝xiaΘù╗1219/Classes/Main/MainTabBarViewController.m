//
//  MainTabBarViewController.m
//  实战项目20151205
//
//  Created by tarena on 15/12/5.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "MainTabBarViewController.h"
#import "FirstViewController.h"
#import "SecondViewController.h"
#import "ThirdViewController.h"
#import "FourthViewController.h"
#import "FifthViewController.h"
#import "XTCenterBtnImages.h"
#import "XTAnimator.h"

@interface MainTabBarViewController ()

@end

@implementation MainTabBarViewController

singleton_implementation(MainTabBarViewController)

- (void)viewDidLoad {
    [super viewDidLoad];
    [self configUserDefaults];
    [self configTabBarController];
    self.selectedIndex = 2;
}

- (void)configUserDefaults
{
    self.notFirstStart = [[[NSUserDefaults standardUserDefaults] valueForKey:@"notfirstStart"] boolValue];
    
    if (!self.notFirstStart) {
        [[NSUserDefaults standardUserDefaults] setInteger:0 forKey:@"appOpenCount"];
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"notfirstStart"];
        self.appOpenCount = [[[NSUserDefaults standardUserDefaults] valueForKey:@"appOpenCount"] integerValue];
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"appOpenCount"];
    } else {
        self.appOpenCount = [[[NSUserDefaults standardUserDefaults] valueForKey:@"appOpenCount"] integerValue];
        [[NSUserDefaults standardUserDefaults] setInteger:self.appOpenCount + 1 forKey:@"appOpenCount"];
    }
}


- (void)configTabBarController
{

    FirstViewController *firstVC = [FirstViewController new];
    UINavigationController *firstNavi = [[UINavigationController alloc] initWithRootViewController:firstVC];
    firstVC.title = @"天气";
    firstVC.tabBarItem.image = [UIImage imageNamed:@"weather"];
    [firstVC.tabBarItem setSelectedImage:[[UIImage imageNamed:@"weather_hl"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];

    SecondViewController *secondVC = [SecondViewController new];
    UINavigationController *secondNavi = [[UINavigationController alloc] initWithRootViewController:secondVC];
    secondVC.title = @"星座";
    secondVC.tabBarItem.image = [UIImage imageNamed:@"star"];
    [secondVC.tabBarItem setSelectedImage:[[UIImage imageNamed:@"star_hl"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];

    ThirdViewController *thirdVC = [[ThirdViewController alloc] init];
    UINavigationController *thirdNavi = [[UINavigationController alloc] initWithRootViewController:thirdVC];
    thirdVC.title = @"新闻";
    [self addCenterImageAndBtn];

    FourthViewController *fourthVC = [FourthViewController new];
    UINavigationController *fourthNavi = [[UINavigationController alloc] initWithRootViewController:fourthVC];
    fourthVC.title = @"生活";
    fourthVC.tabBarItem.image = [UIImage imageNamed:@"life"];
    [fourthVC.tabBarItem setSelectedImage:[[UIImage imageNamed:@"life_hl"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];

    FifthViewController *fifthVC = [FifthViewController new];
    UINavigationController *fifthNavi = [[UINavigationController alloc] initWithRootViewController:fifthVC];
    fifthVC.title = @"我";
    fifthVC.tabBarItem.image = [UIImage imageNamed:@"me"];
    [fifthVC.tabBarItem setSelectedImage:[[UIImage imageNamed:@"me_hl"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];

    self.viewControllers = @[firstNavi,secondNavi,thirdNavi,fourthNavi,fifthNavi];

}


- (void)addCenterImageAndBtn
{
    UIImage *image = [[XTCenterBtnImages sharedXTCenterBtnImages].allImages lastObject];

    UIImageView *imageView = [[UIImageView alloc] initWithImage:image];

    imageView.frame = CGRectMake(0, 0, 64, 64);

    CGFloat heightDifference = 128 - self.tabBar.frame.size.height;
    if (heightDifference < 0)
        imageView.center = self.tabBar.center;
    else
    {
        CGPoint center = self.tabBar.center;
        center.x = self.tabBar.center.x - 3;
        center.y = center.y - heightDifference/2.0 + 28;
        imageView.center = center;
    }
    self.centerIV = imageView;
    [self.view addSubview:self.centerIV];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = imageView.bounds;
    imageView.userInteractionEnabled = YES;
    button.backgroundColor = [UIColor clearColor];
    [imageView addSubview:button];
    [button addTarget:self action:@selector(newsBtnClick) forControlEvents:UIControlEventTouchUpInside];
}

- (void)newsBtnClick
{
    [self setSelectedIndex:2];
    NSMutableArray *imagesArr = [[XTCenterBtnImages sharedXTCenterBtnImages].allImages mutableCopy];
    [imagesArr removeLastObject];
    [[XTAnimator sharedXTAnimator] animateWithImages:imagesArr onImageView:self.centerIV inDuration:CENTER_BTN_ANIMATING_DURATION];
    self.centerIV.image = [[XTCenterBtnImages sharedXTCenterBtnImages].allImages lastObject];
}





@end
