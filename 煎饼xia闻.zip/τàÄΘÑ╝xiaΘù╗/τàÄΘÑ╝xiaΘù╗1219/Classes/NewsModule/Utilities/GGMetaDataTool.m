//
//  GGMetaDataTool.m
//  改名后
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "GGMetaDataTool.h"
#import "GGNews.h"
@implementation GGMetaDataTool
+ (void)getNewsWithNewsCategory:(NSString *)newsCategory andReturnNumberPerQequest:(int)returnNum andCurrentPage:(NSInteger)currentPage parseFinished:(MyBlock)myBlock {
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"num"] = @(returnNum);
    parameters[@"page"] = @(currentPage);
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    [manager.requestSerializer setValue:NEWSAPIKEY forHTTPHeaderField:@"apikey"];
    [manager GET:newsCategory parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *jsonDic = (NSDictionary *)responseObject;
        NSArray *arr = [self parse:newsCategory withJSONDic:jsonDic andReturnNumber:returnNum];
        myBlock(arr);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [MBProgressHUD showError:@"网络错误"];
    }];
}
+ (NSArray *)parse:(NSString *)newsCategory withJSONDic:(NSDictionary *)jsonDic andReturnNumber:(int)returnNum {
    NSMutableArray *mutableArray = [NSMutableArray array];
    for (int i = 0; i < returnNum; i++) {
        NSString *str = [NSString stringWithFormat:@"%d", i];
        GGNews *news = [GGNews new];
        news.title = jsonDic[str][@"title"];
        news.desc = jsonDic[str][@"description"];
        news.picUrl = jsonDic[str][@"picUrl"];
        news.url = jsonDic[str][@"url"];
        if ([newsCategory  isEqual: @"http://apis.baidu.com/txapi/weixin/wxhot"]) {
            news.time = jsonDic[str][@"hottime"];
        } else {
            news.time = jsonDic[str][@"time"];
        }
        [mutableArray addObject:news];
    }
    [mutableArray removeLastObject];
    return [mutableArray copy];
    
}
@end
