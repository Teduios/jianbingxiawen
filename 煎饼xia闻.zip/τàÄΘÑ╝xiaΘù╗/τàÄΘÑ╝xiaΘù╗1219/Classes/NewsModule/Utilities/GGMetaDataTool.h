//
//  GGMetaDataTool.h
//  改名后
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef void (^MyBlock)(NSArray *parsedArray);
@interface GGMetaDataTool : NSObject
+ (void)getNewsWithNewsCategory:(NSString *)newsCategory andReturnNumberPerQequest:(int)returnNum andCurrentPage:(NSInteger)currentPage parseFinished:(MyBlock)myBlock;
@end
