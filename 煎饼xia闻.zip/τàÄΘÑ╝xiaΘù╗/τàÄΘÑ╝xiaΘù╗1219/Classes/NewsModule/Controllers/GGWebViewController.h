//
//  GGWebViewController.h
//  实战项目20151205
//
//  Created by tarena on 15/12/13.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GGWebViewController : UIViewController

@property (nonatomic, strong) NSString *url;

@end
