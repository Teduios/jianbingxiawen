//
//  ThirdViewController.h
//  改名后
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MMDrawerController.h"
@interface ThirdViewController : MMDrawerController

@end
