//
//  LeftViewController.m
//  改名后
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "LeftViewController.h"
#import "GGCategoryTableView.h"
#import "YLImageView.h"
#import "YLGIFImage.h"
@interface LeftViewController ()
@property (nonatomic, strong) YLImageView *headView;
@property (nonatomic, strong) GGCategoryTableView *newsTableView;
@end

@implementation LeftViewController
- (YLImageView *)headView {
    if (!_headView) {
        _headView = [[YLImageView alloc] init];
        _headView.image = [YLGIFImage imageNamed:@"category5.gif"];
    }
    return _headView;
}
- (GGCategoryTableView *)newsTableView {
    if (!_newsTableView) {
        _newsTableView = [[GGCategoryTableView alloc] init];
        _newsTableView.tableFooterView = [UIView new];
        _newsTableView.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"blue4"]];
        _newsTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    }
    return _newsTableView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor clearColor];
    self.newsTableView.backgroundColor = [UIColor clearColor];
    [self.view insertSubview:self.newsTableView atIndex:0];
    self.headView.backgroundColor = [UIColor grayColor];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeImage:) name:@"changeImage" object:nil];
    [self.view addSubview:self.headView];
    [self setConstraint];
}
- (void)changeImage:(NSNotification *)noti {
        NSDictionary *gifDic = @{@"体育新闻" : @"category2", @"国际新闻" : @"category7", @"奇闻逸事" : @"category3", @"娱乐花边" : @"category4", @"微信精选" : @"category6", @"生活健康" : @"category1", @"社会新闻" : @"category5", @"科技新闻" : @"category8", };
    self.headView.image = [YLGIFImage imageNamed:[NSString stringWithFormat:@"%@.gif", gifDic[noti.object]]];
}
- (void)setConstraint {
    float headerViewHeight = 0;
    if (CURRENT_DEVICE == 4) {
        headerViewHeight = 85;
    } else if (CURRENT_DEVICE == 5) {
        headerViewHeight = 100;
    } else if (CURRENT_DEVICE == 6) {
        headerViewHeight = 125;
    } else if (CURRENT_DEVICE == 7) {
        headerViewHeight = 150;
    }
    [self.headView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view.mas_top).with.offset(64);
        make.left.equalTo(self.view.mas_left).with.offset(0);
        make.right.equalTo(self.view.mas_right).with.offset(0);
        make.height.mas_equalTo(headerViewHeight);
    }];
    [self.newsTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.headView.mas_bottom).with.offset(-64);
        make.left.equalTo(self.view.mas_left).with.offset(0);
        make.right.equalTo(self.view.mas_right).with.offset(0);
        make.bottom.equalTo(self.view.mas_bottom).with.offset(0);
    }];
}
- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
