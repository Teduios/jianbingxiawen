//
//  CenterViewController.m
//  改名后
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "CenterViewController.h"
#import "UIViewController+MMDrawerController.h"
#import "GGNewsTableView.h"
#import "INSSearchBar.h"
#import "GGMetaDataTool.h"
#import "GGNews.h"
#import "GGWebViewController.h"
#import "GGNewsRequestParamters.h"
static float buttonHeight;
static float buttonWidth;
static float buttonX;
static float buttonY;
@interface CenterViewController ()< UIViewControllerPreviewingDelegate>

@property (nonatomic, strong) UIButton *button;

@property (nonatomic, strong) GGNewsTableView *tableView;

@property (nonatomic, strong) UITableViewCell *cell;

@end

@implementation CenterViewController
- (UIButton *)button {
    if (!_button) {
        self.button = [[UIButton alloc] init];
        
    }
    return _button;
}
- (GGNewsTableView *)tableView {
    if (!_tableView) {
        _tableView = [[GGNewsTableView alloc] init];
        _tableView.tableFooterView = [UIView new];
    }
    return _tableView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [GGNewsRequestParamters sharedGGNewsRequestParamters].category = @"http://apis.baidu.com/txapi/social/social";
    [GGNewsRequestParamters sharedGGNewsRequestParamters].page = 1;
    [self configSubviews];
    self.view.backgroundColor = [UIColor clearColor];
    
    if ([[UIDevice currentDevice].systemVersion doubleValue] > 9.0) {
        if(self.traitCollection.forceTouchCapability == UIForceTouchCapabilityAvailable)
        {
            [self registerForPreviewingWithDelegate:self sourceView:self.view];
        }else{
        }
        
    }
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self addNotification];
}
- (void)addNotification {
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(hideButton) name:@"hideButton" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showButton) name:@"showButton" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(hideAndSkipTop) name:@"hideLeftView" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadTableView:) name:@"reload" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(skipToNews:) name:@"skipToWebView" object:nil];
}
- (void)skipToNews:(NSNotification *)notification {
    GGWebViewController *web = [[GGWebViewController alloc] init];
    web.url = notification.object;
    [self presentViewController:[[UINavigationController alloc] initWithRootViewController:web] animated:YES completion:nil];
    
}

- (void)reloadTableView:(NSNotification*)notification {

    self.tableView.mutableArray = notification.userInfo[@"mutableDic"];
    [self.tableView reloadData];
}

- (void) configSubviews {

    self.tableView.backgroundColor = [UIColor clearColor];
    [self.view insertSubview:self.tableView atIndex:0];
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view.mas_top).with.offset(64);
        make.left.equalTo(self.view.mas_left).with.offset(0);
        make.right.equalTo(self.view.mas_right).with.offset(0);
        make.bottom.equalTo(self.view.mas_bottom).with.offset(-45);
    }];

    if (CURRENT_DEVICE == 4) {
        buttonWidth = 33;
        buttonHeight = 33;
        buttonX = 40;
        buttonY = 380;
    } else if (CURRENT_DEVICE == 5) {
        buttonWidth = 37;
        buttonHeight = 37;
        buttonX = 40;
        buttonY = 460;
    } else if (CURRENT_DEVICE == 6) {
        buttonWidth = 40;
        buttonHeight = 40;
        buttonX = 50;
        buttonY = 540;
    } else if (CURRENT_DEVICE == 7) {
        buttonWidth = 44;
        buttonHeight = 44;
        buttonX = 60;
        buttonY = 600;
    }
    self.button.backgroundColor = [UIColor grayColor];
    [self.button setFrame:CGRectMake(buttonX, buttonY, buttonWidth, buttonHeight)];
    self.button.layer.masksToBounds = YES;
    self.button.layer.cornerRadius = self.button.frame.size.width/2;
    [self.button setBackgroundImage:[UIImage imageNamed:@"cate"] forState:UIControlStateNormal];
    self.button.alpha = .7f;
    [self.button addTarget:self action:@selector(pushAndPullMenu) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.button];
}
- (void)hideButton {
    self.button.hidden = YES;
    
}

- (void)showButton {
    self.button.hidden = NO;
    
    
}

- (void)hideAndSkipTop {

    [self.tableView setContentOffset:CGPointMake(0, 0) animated:YES];
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

- (void) pushAndPullMenu {
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

#pragma mark peek && pop 代理方法
- (nullable UIViewController *)previewingContext:(id <UIViewControllerPreviewing>)previewingContext viewControllerForLocation:(CGPoint)location {
    CGPoint point = [self.view convertPoint:location toView:self.tableView];
    NSArray *cells = self.tableView.visibleCells;
    UITableViewCell *selectCell = nil;
    for (UITableViewCell *cell in cells) {
        BOOL bo = CGRectContainsPoint(cell.frame, point);
        if (bo) {
            selectCell = cell;
            break;
        }
        
    }
    self.cell = selectCell;
    CGRect rect = selectCell.frame;
    rect = [self.tableView convertRect:rect toView:self.view];
    previewingContext.sourceRect = rect;
    UIViewController *peekVC = [[UIViewController alloc] init];
    UIView *backgroundView =[[UIView alloc] initWithFrame:CGRectMake(25, 30, SCREEN_WIDTH - 50, SCREEN_HEIGHT - 80 * 2)];
    backgroundView.backgroundColor = [UIColor whiteColor];
    backgroundView.layer.cornerRadius = 10;
    backgroundView.clipsToBounds = YES;
    [peekVC.view addSubview:backgroundView];
    UILabel *lable = [[UILabel alloc] initWithFrame:backgroundView.bounds];
    lable.textAlignment = NSTextAlignmentCenter;
    lable.text = @"再按重一点以查看详情...";
    [backgroundView addSubview:lable];
    
    return peekVC;
}
- (void)previewingContext:(id <UIViewControllerPreviewing>)previewingContext commitViewController:(UIViewController *)viewControllerToCommit {
    NSIndexPath *indexPath = [self.tableView indexPathForCell:self.cell];
    [self tableView:self.tableView didSelectRowAtIndexPath:indexPath];
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    GGNews *news = self.tableView.mutableArray[indexPath.row];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"skipToWebView" object:news.url];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.mm_drawerController closeDrawerAnimated:YES completion:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    if (self.tableView.synthesizer.speaking) {
        [self.tableView.synthesizer stopSpeakingAtBoundary:AVSpeechBoundaryWord];
        return;
    }
}
@end
