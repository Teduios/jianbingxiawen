//
//  GGWebViewController.m
//  实战项目20151205
//
//  Created by tarena on 15/12/13.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "GGWebViewController.h"

@interface GGWebViewController () <UIWebViewDelegate>

@end

@implementation GGWebViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"新闻阅读";
    UIBarButtonItem *left = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(goBack)];
    self.navigationItem.leftBarButtonItem = left;
    UIWebView *webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [self.view addSubview:webView];
    webView.backgroundColor = [UIColor lightGrayColor];
    NSString *urlStr = self.url;
    NSURL *url = [NSURL URLWithString:urlStr];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    webView.delegate = self;
    [webView loadRequest:request];
}
- (void)goBack {
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    [self dismissViewControllerAnimated:YES completion:nil];

}
#pragma mark -- UIWebViewDelegate
- (void)webViewDidStartLoad:(UIWebView *)webView{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self shouldChangeTheme];
}
#pragma mark----ChangeTheme
- (void)shouldChangeTheme {
    BOOL status = [FifthViewController sharedFifthViewController].ThemeSwitchStatus;
    if (status) {
        self.navigationController.navigationBar.barStyle  = UIBarStyleBlack;
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
        self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    } else {
        self.navigationController.navigationBar.barStyle  = UIBarStyleDefault;
        self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
        
    }
}

@end
