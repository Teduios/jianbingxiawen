//
//  ThirdViewController.m
//  改名后
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "ThirdViewController.h"
#import "CenterViewController.h"
#import "LeftViewController.h"
#import "MainTabBarViewController.h"
#import "XTCenterBtnImages.h"
#import "XTAnimator.h"


#define GUIDE_VIEW @"pic1.jpg"
#define DAY_TIME_BACKGROUNDIMAGE_NAME @"pic42"
#define NIGHT_BACKGROUNDIMAGE_NAME @"pic13"

@interface ThirdViewController ()
@property (nonatomic, strong) XTGuideViewTool *tool;
@end

@implementation ThirdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor clearColor];
    LeftViewController *leftController = [LeftViewController new];
    CenterViewController *centerController = [CenterViewController new];
    self.leftDrawerViewController = leftController;
    self.centerViewController = centerController;
    
    [self setShowsShadow:NO];
    
    [self setMaximumRightDrawerWidth:200.0];
    [self setOpenDrawerGestureModeMask:MMOpenDrawerGestureModeAll];
    [self setCloseDrawerGestureModeMask:MMCloseDrawerGestureModeAll];
    self.navigationItem.title = @"社会新闻";
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeTitleName:) name:@"hideLeftView" object:nil];
    
    XTGuideViewTool *tool = [XTGuideViewTool showGuideView];
    self.tool = tool;
    UIImageView *buttonImageView = [UIImageView new];
    buttonImageView.image = [UIImage imageNamed:@"newsButton"];
    UIImageView *readImageView = [UIImageView new];
    readImageView.image = [UIImage imageNamed:@"newsRead"];
    UIImageView *touchImageView = [UIImageView new];
    touchImageView.image = [UIImage imageNamed:@"news3D"];
    if (CURRENT_DEVICE == 4) {
        buttonImageView.frame = CGRectMake(-58, 210, 400, 230);
        readImageView.frame = CGRectMake(0, 60, 400, 250);
        [tool.guideImageView addSubview:readImageView];
    } else if (CURRENT_DEVICE == 5) {
        buttonImageView.frame = CGRectMake(-58, 290, 400, 230);
        readImageView.frame = CGRectMake(0, 130, 400, 250);
        [tool.guideImageView addSubview:readImageView];
    } else if (CURRENT_DEVICE == 6) {
        buttonImageView.frame = CGRectMake(-58, 370, 420, 230);
        readImageView.frame = CGRectMake(0, 150, 420, 250);
        touchImageView.frame = CGRectMake(0, 40, 420, 250);
        [tool.guideImageView addSubview:readImageView];
    } else if (CURRENT_DEVICE == 7) {
        buttonImageView.frame = CGRectMake(-50, 430, 420, 230);
        readImageView.frame = CGRectMake(0, 160, 420, 250);
        touchImageView.frame = CGRectMake(50, 40, 420, 250);
        [tool.guideImageView addSubview:touchImageView];
    }
    [tool.guideImageView addSubview:buttonImageView];

}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self shouldChangeTheme];
}
#pragma mark----ChangeTheme
- (void)shouldChangeTheme {
    BOOL status = [FifthViewController sharedFifthViewController].ThemeSwitchStatus;
    if (status) {
        self.navigationController.navigationBar.barStyle  = UIBarStyleBlack;
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
        self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
        
    } else {
        self.navigationController.navigationBar.barStyle  = UIBarStyleDefault;
        self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];

    }
}

- (void)changeTitleName:(NSNotification *)noti {
    self.navigationItem.title = noti.object;
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    NSArray *allReverseImages = [XTCenterBtnImages traversalArray:[XTCenterBtnImages sharedXTCenterBtnImages].allImages withClockwise:NO];
    NSMutableArray *imagesArr = [allReverseImages mutableCopy];
    [imagesArr removeObjectAtIndex:0];
    [[XTAnimator sharedXTAnimator] animateWithImages:imagesArr onImageView:[MainTabBarViewController sharedMainTabBarViewController].centerIV inDuration:CENTER_BTN_ANIMATING_DURATION];
    [MainTabBarViewController sharedMainTabBarViewController].centerIV.image = [[XTCenterBtnImages sharedXTCenterBtnImages].allImages firstObject];
    [MainTabBarViewController sharedMainTabBarViewController].centerIV.userInteractionEnabled = YES;
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    if ([MainTabBarViewController sharedMainTabBarViewController].selectedIndex == 2) {
        [MainTabBarViewController sharedMainTabBarViewController].centerIV.image = [[XTCenterBtnImages sharedXTCenterBtnImages].allImages lastObject];
        [MainTabBarViewController sharedMainTabBarViewController].centerIV.userInteractionEnabled = NO;
    }
    
}

@end
