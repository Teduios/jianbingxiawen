//
//  GGCustomTableViewCell.m
//  改名后
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "GGCustomTableViewCell.h"
#import "UIImageView+WebCache.h"

static float newsTitleFont;
static float newsLittleFont;

@implementation GGCustomTableViewCell
+ (id)cellWithTableView:(UITableView *)tableView {
    static NSString *identifier = @"newsCell";
    GGCustomTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[GGCustomTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.newsImageView = [[UIImageView alloc] init];
        self.titleLabel = [[UILabel alloc] init];
        self.dateLabel = [[UILabel alloc] init];
        [self.contentView addSubview:self.newsImageView];
        [self.contentView addSubview:self.titleLabel];
        [self.contentView addSubview:self.dateLabel];
        if (CURRENT_DEVICE == 4) {
            newsTitleFont = 17;
            newsLittleFont = 10;
        } else if (CURRENT_DEVICE == 5) {
            newsTitleFont = 18;
            newsLittleFont = 11;
        } else if (CURRENT_DEVICE == 6) {
            newsTitleFont = 19;
            newsLittleFont = 12;
        } else if (CURRENT_DEVICE == 7) {
            newsTitleFont = 20;
            newsLittleFont = 13;
        }
        self.newsImageView.layer.cornerRadius = 10;
        self.newsImageView.layer.masksToBounds = YES;
        self.newsImageView.translatesAutoresizingMaskIntoConstraints = NO;
        [self.newsImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.contentView.mas_top).with.offset(5);
            make.bottom.equalTo(self.contentView.mas_bottom).with.offset(-5);
            make.left.equalTo(self.contentView.mas_left).with.offset(5);
            make.width.mas_equalTo(SCREEN_WIDTH/4+20);
        }];
        self.dateLabel.font = [UIFont systemFontOfSize:newsLittleFont];
        self.dateLabel.textColor = [UIColor lightGrayColor];
        self.dateLabel.textAlignment = NSTextAlignmentLeft;
        self.dateLabel.translatesAutoresizingMaskIntoConstraints = NO;
        [self.dateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.self.newsImageView.mas_right).with.offset(5);
            make.bottom.equalTo(self.contentView.mas_bottom).with.offset(-2);
            make.height.mas_equalTo(@15);
        }];
        self.titleLabel.font = [UIFont systemFontOfSize:newsTitleFont];
        self.titleLabel.textAlignment = NSTextAlignmentLeft;
        self.titleLabel.numberOfLines = 0;
        self.titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
        [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.contentView.mas_top).with.offset(2);
            make.left.equalTo(self.newsImageView.mas_right).with.offset(5);
            make.right.equalTo(self.contentView.mas_right).with.offset(-5);
            make.bottom.equalTo(self.dateLabel.mas_top).offset(-2);
        }];
    }
    return self;
}
- (void)setYynews:(GGNews *)yynews {
    self.titleLabel.text = yynews.title;
    self.dateLabel.text = yynews.time;
    if (yynews.picUrl.length < 1) {
        [self.newsImageView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.contentView.mas_top).with.offset(5);
            make.bottom.equalTo(self.contentView.mas_bottom).with.offset(-5);
            make.left.equalTo(self.contentView.mas_left).with.offset(5);
            make.width.mas_equalTo(0);
        }];
        [self layoutIfNeeded];
    } else {
        [self.newsImageView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.contentView.mas_top).with.offset(5);
            make.bottom.equalTo(self.contentView.mas_bottom).with.offset(-5);
            make.left.equalTo(self.contentView.mas_left).with.offset(5);
            make.width.mas_equalTo(SCREEN_WIDTH/4 + 20);
        }];
        [self layoutIfNeeded];
    }
    [self.newsImageView sd_setImageWithURL:[NSURL URLWithString:yynews.picUrl] placeholderImage:[UIImage imageNamed:@"1"] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
    }];
}

@end
