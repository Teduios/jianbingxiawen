//
//  GGNewsTableView.m
//  改名后
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "GGNewsTableView.h"
#import "GGMetaDataTool.h"
#import "GGNews.h"
#import "GGCustomTableViewCell.h"
#import "CenterViewController.h"
#import "ThirdViewController.h"
#import "MJRefresh.h"
#import "GGNewsRequestParamters.h"
#import "NewsTitleReadGesRecongnizer.h"

@interface GGNewsTableView ()
@property (nonatomic, assign) BOOL finishLoading;

@end

@implementation GGNewsTableView

- (AVSpeechSynthesizer *)synthesizer {
    if(_synthesizer == nil) {
        _synthesizer = [[AVSpeechSynthesizer alloc] init];
    }
    return _synthesizer;
}

- (NSMutableArray *)mutableArray {
    if (!_mutableArray) {
        _mutableArray = [NSMutableArray array];
    }
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(resetRefresh) name:@"resetRefresh" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(resetRefresh) name:@"reload" object:nil];
    return _mutableArray;
}
- (instancetype)init {
    if (self = [super init]) {
        self.delegate = self;
        self.dataSource =self;
    }
    self.mj_header = [MJRefreshNormalHeader headerWithRefreshingTarget:self refreshingAction:@selector(downPull:)];
    [self.mj_header beginRefreshing];
    
    self.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(upPull:)];
    [FifthViewController sharedFifthViewController].LongPressSwitchStatus = NO;
    
    return self;
}
- (void)downPull:(MJRefreshNormalHeader *)header {
    [GGMetaDataTool getNewsWithNewsCategory:[GGNewsRequestParamters sharedGGNewsRequestParamters].category andReturnNumberPerQequest:REQUEST_NEWS_NUM_PERTIME andCurrentPage:1 parseFinished:^(NSArray *parsedArray) {
        [self.mutableArray removeAllObjects];
        for (GGNews *news in parsedArray) {
            [self.mutableArray addObject:news];
        }
        [self reloadData];
    }];
    
    [self resetRefresh];
    [header endRefreshing];
}

- (void)upPull:(MJRefreshAutoNormalFooter *)footer {
    [GGNewsRequestParamters sharedGGNewsRequestParamters].page += 1;
    [GGMetaDataTool getNewsWithNewsCategory:[GGNewsRequestParamters sharedGGNewsRequestParamters].category andReturnNumberPerQequest:REQUEST_NEWS_NUM_PERTIME andCurrentPage:[GGNewsRequestParamters sharedGGNewsRequestParamters].page parseFinished:^(NSArray *parsedArray) {
        if (parsedArray.count == 0) {
            self.finishLoading = YES;
        }
        for (GGNews *news in parsedArray) {
            [self.mutableArray addObject:news];
        }
        [self reloadData];
        
    }];
    if (self.finishLoading == YES) {
        [footer endRefreshingWithNoMoreData];
    } else {
        [footer endRefreshing];
    }
}

- (void)resetRefresh {
    [self.mj_footer resetNoMoreData];
}
#pragma mark - Table view data source
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.mutableArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    GGCustomTableViewCell *cell = [GGCustomTableViewCell cellWithTableView:tableView];
    
    NewsTitleReadGesRecongnizer *longPressGes = [[NewsTitleReadGesRecongnizer alloc] initWithTarget:self action:@selector(startReadTitle:)];
    longPressGes.indexPath = indexPath;
    [cell addGestureRecognizer:longPressGes];
    cell.yynews = self.mutableArray[indexPath.row];
    
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"3D" object:self.mutableArray[indexPath.row]];
    
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    GGNews *news = self.mutableArray[indexPath.row];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:@"skipToWebView" object:news.url];
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (CURRENT_DEVICE == 4) {
        return 70;
    } else if (CURRENT_DEVICE == 5) {
        return 80;
    } else if (CURRENT_DEVICE == 6) {
        return 90;
    } else if (CURRENT_DEVICE == 7) {
        return 100;
    }
    return 100;
}

- (void)startReadTitle:(NewsTitleReadGesRecongnizer *)longPressGes
{
    GGCustomTableViewCell *cell = [self cellForRowAtIndexPath:longPressGes.indexPath];
    
    if(longPressGes.state == UIGestureRecognizerStateBegan)
    {
        CGPoint point = [longPressGes locationInView:self];
        NSIndexPath * indexPath = [self indexPathForRowAtPoint:point];
        if(indexPath == nil) return ;
        
        AVSpeechUtterance *utterance = [AVSpeechUtterance speechUtteranceWithString:cell.titleLabel.text];
        utterance.voice = [AVSpeechSynthesisVoice voiceWithLanguage:@"zh-CN"];
        utterance.rate = 0.4f;
        if ([FifthViewController sharedFifthViewController].LongPressSwitchStatus) {
            [self.synthesizer speakUtterance:utterance];
        }
        
    }
}

- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    [[NSNotificationCenter defaultCenter] postNotificationName:@"hideButton" object:nil];
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"showButton" object:nil];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
