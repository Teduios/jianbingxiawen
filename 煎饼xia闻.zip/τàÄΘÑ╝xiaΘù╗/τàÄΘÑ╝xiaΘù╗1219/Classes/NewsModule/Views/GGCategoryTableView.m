//
//  GGCategoryTableView.m
//  改名后
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "GGCategoryTableView.h"
#import "GGNewsCategory.h"
#import "GGMetaDataTool.h"
#import "GGNews.h"
#import "GGNewsTableView.h"
#import "GGNewsRequestParamters.h"

@implementation GGCategoryTableView
- (instancetype)init {
    if (self = [super init]) {
        self.delegate = self;
        self.dataSource = self;
    }
    return self;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    GGNewsCategory *newsCategory = [GGNewsCategory new];
    return newsCategory.newsCategoryArray.count;
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"newsCategory"];
    GGNewsCategory *news= [[GGNewsCategory alloc] init];
    
    cell.backgroundColor = [UIColor clearColor];
    UIImageView *view = [UIImageView new];
    view.image = [UIImage imageNamed:@"gold2"];
    int y = 0;
    int height;
    if (CURRENT_DEVICE == 4) {
        y = cell.contentView.frame.size.height+3;
        height = 2;
    } else if (CURRENT_DEVICE == 5) {
        y = cell.contentView.frame.size.height+3;
        height = 4;
    } else if (CURRENT_DEVICE == 6) {
        y = cell.contentView.frame.size.height+8;
        height = 6;
    } else if (CURRENT_DEVICE == 7) {
        y = cell.contentView.frame.size.height+14;
        height = 8;
    }
    view.frame = CGRectMake(0, y, cell.contentView.frame.size.width, height);
    [cell.contentView addSubview:view];

    
    
    cell.textLabel.textColor = [UIColor whiteColor];
    cell.textLabel.text = [[news.newsCategoryArray[indexPath.row] allKeys] lastObject];
    if (CURRENT_DEVICE == 4) {
        cell.textLabel.font = [UIFont systemFontOfSize:12];
    } else if (CURRENT_DEVICE == 5) {
        cell.textLabel.font = [UIFont systemFontOfSize:16];
    } else if (CURRENT_DEVICE == 6) {
        cell.textLabel.font = [UIFont systemFontOfSize:20];
    } else if (CURRENT_DEVICE == 7) {
        cell.textLabel.font = [UIFont boldSystemFontOfSize:23];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    GGNewsCategory *news = [[GGNewsCategory alloc] init];
    NSDictionary *categoryDic = news.newsCategoryArray[indexPath.row];
    NSString *categoryName = [[categoryDic allKeys] lastObject];
    NSString *categoryURL = [[categoryDic allValues] lastObject];
    [self requestCategory:categoryURL];
    NSString *category = categoryURL;
    [GGNewsRequestParamters sharedGGNewsRequestParamters].category = category;
    [[NSNotificationCenter defaultCenter] postNotificationName:@"hideLeftView" object:categoryName];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"resetRefresh" object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"changeImage" object:categoryName];
    
}
- (void)requestCategory:(NSString *)category {
    [GGNewsRequestParamters sharedGGNewsRequestParamters].page = 1;
    [GGMetaDataTool getNewsWithNewsCategory:category andReturnNumberPerQequest:REQUEST_NEWS_NUM_PERTIME andCurrentPage:[GGNewsRequestParamters sharedGGNewsRequestParamters].page parseFinished:^(NSArray *parsedArray) {
        GGNewsTableView *newsTable = [[GGNewsTableView alloc] init];
        [newsTable.mutableArray removeAllObjects];
        for (GGNews *news in parsedArray) {
            [newsTable.mutableArray addObject:news];
        }
        [[NSNotificationCenter defaultCenter] postNotificationName:@"reload" object:self userInfo:@{@"mutableDic" : newsTable.mutableArray}];
    }];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    if (CURRENT_DEVICE == 4) {
        return 44;
    } else if (CURRENT_DEVICE == 5) {
        return 50;
    } else if (CURRENT_DEVICE == 6) {
        return 58;
    } else if (CURRENT_DEVICE == 7) {
        return 65;
    }
    return 65;
    
}
@end
