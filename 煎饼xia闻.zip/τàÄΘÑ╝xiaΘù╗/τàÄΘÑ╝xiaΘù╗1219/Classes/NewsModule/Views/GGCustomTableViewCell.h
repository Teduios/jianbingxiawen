//
//  GGCustomTableViewCell.h
//  改名后
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GGNews.h"


@interface GGCustomTableViewCell : UITableViewCell
+ (id)cellWithTableView:(UITableView *)tableView;
@property (nonatomic, strong) GGNews *yynews;
@property (nonatomic, strong) UIImageView * newsImageView;
@property (nonatomic, strong) UILabel * titleLabel;
@property (nonatomic, strong) UILabel * dateLabel;


@end
