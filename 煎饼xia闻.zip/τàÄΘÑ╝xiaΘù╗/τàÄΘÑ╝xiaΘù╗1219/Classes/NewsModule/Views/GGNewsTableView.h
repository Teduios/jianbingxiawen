//
//  GGNewsTableView.h
//  改名后
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
@interface GGNewsTableView : UITableView<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic, strong)NSMutableArray *mutableArray;
@property (strong, nonatomic) AVSpeechSynthesizer *synthesizer;
@end
