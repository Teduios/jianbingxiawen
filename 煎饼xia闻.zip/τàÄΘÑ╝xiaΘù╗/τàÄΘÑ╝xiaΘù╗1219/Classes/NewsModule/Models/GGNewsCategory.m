//
//  GGNewsCategory.m
//  改名后
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "GGNewsCategory.h"

@implementation GGNewsCategory
- (NSArray *)newsCategoryArray {
    if (!_newsCategoryArray) {
        _newsCategoryArray = @[@{@"社会新闻":@"http://apis.baidu.com/txapi/social/social"}, @{@"国际新闻":@"http://apis.baidu.com/txapi/world/world"}, @{@"体育新闻":@"http://apis.baidu.com/txapi/tiyu/tiyu"}, @{@"科技新闻":@"http://apis.baidu.com/txapi/keji/keji"}, @{@"娱乐花边":@"http://apis.baidu.com/txapi/huabian/newtop"}, @{@"生活健康":@"http://apis.baidu.com/txapi/health/health"}, @{@"奇闻逸事":@"http://apis.baidu.com/txapi/qiwen/qiwen"}, @{@"微信精选":@"http://apis.baidu.com/txapi/weixin/wxhot"}];
    }
    return _newsCategoryArray;
}

@end
