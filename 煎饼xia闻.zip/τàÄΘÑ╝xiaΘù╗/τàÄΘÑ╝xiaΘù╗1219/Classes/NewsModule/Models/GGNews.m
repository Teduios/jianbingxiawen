//
//  GGNews.m
//  改名后
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "GGNews.h"

@implementation GGNews
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    if ([key isEqualToString:@"description"]) {
        self.desc = value;
    }
}
- (void)setNilValueForKey:(NSString *)key{}
@end
