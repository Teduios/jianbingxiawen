//
//  GGNewsCategory.h
//  改名后
//
//  Created by tarena on 15/12/12.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GGNewsCategory : NSObject
@property (nonatomic, strong) NSArray *newsCategoryArray;
@end
