//
//  GGNewsRequestParamters.m
//  实战项目20151205
//
//  Created by tarena on 15/12/15.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "GGNewsRequestParamters.h"

@implementation GGNewsRequestParamters
singleton_implementation(GGNewsRequestParamters)
@end
