//
//  TPWeatherData.m
//  TPWeather
//
//  Created by Tpy on 15/12/6.
//  Copyright © 2015年 tpy. All rights reserved.
//

#import "TPWeatherData.h"

@implementation TPWeatherData

@end
