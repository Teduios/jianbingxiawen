//
//  TPWeatherIcon.h
//  TPWeather
//
//  Created by Tpy on 15/12/6.
//  Copyright © 2015年 tpy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TPWeatherIcon : NSObject


@property (nonatomic, strong) NSNumber *weatid;

@property (nonatomic, strong) NSString *weather;

@property (nonatomic, strong) NSNumber *weather_icon;


@end
