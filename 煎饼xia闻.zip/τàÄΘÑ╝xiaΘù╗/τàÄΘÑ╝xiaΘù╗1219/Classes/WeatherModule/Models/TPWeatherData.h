//
//  TPWeatherData.h
//  TPWeather
//
//  Created by Tpy on 15/12/6.
//  Copyright © 2015年 tpy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TPWeatherData : NSObject


@property (nonatomic, strong) NSString *success;

@property (nonatomic, strong) NSString *msg;

@property (nonatomic, strong) NSString *days;

@property (nonatomic, strong) NSString *week;

@property (nonatomic, strong) NSString *citynm;

@property (nonatomic, strong) NSString *temperature;

@property (nonatomic, strong) NSString *temperature_curr;

@property (nonatomic, strong) NSString *humidity;

@property (nonatomic, strong) NSString *weather;

@property (nonatomic, strong) NSString *weather_icon;

@property (nonatomic, strong) NSString *weather_icon1;

@property (nonatomic, strong) NSString *wind;

@property (nonatomic, strong) NSString *winp;

@property (nonatomic, strong) NSString *temp_high;

@property (nonatomic, strong) NSString *temp_low;

@property (nonatomic, strong) NSString *weatid;




@end
