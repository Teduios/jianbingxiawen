//
//  TPRoundView.h
//  实战项目20151205
//
//  Created by Tpy on 15/12/9.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TPRoundView : UIView

@property (nonatomic, strong) UILabel *daysLabel;

@property (nonatomic, strong) UILabel *weekLabel;

@property (nonatomic, strong) UILabel *citynmLabel;

@property (nonatomic, strong) UILabel *tempCurrLabel;

@property (nonatomic, strong) UILabel *humidityLabel;

@property (nonatomic, strong) UILabel *weatherLabel;

@property (nonatomic, strong) UIImageView *iconView;

@property (nonatomic, strong) UILabel *windLabel;

@property (nonatomic, strong) UILabel *winpLabel;

@property (nonatomic, strong) UILabel *tempHighLabel;

@property (nonatomic, strong) UILabel *tempLowLabel;

- (instancetype)initWithFrame:(CGRect)frame;

@end
