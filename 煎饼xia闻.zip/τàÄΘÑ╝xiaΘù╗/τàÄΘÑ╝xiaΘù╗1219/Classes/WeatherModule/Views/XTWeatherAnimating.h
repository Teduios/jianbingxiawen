//
//  XTWeatherAnimating.h
//  实战项目20151205
//
//  Created by tarena on 15/12/15.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    SNOW = 1,
    RAIN,
    CLOUD
}WEATHERSTATUS;

@interface XTWeatherAnimating : UIView

singleton_interface(XTWeatherAnimating)
@property (nonatomic, strong) NSTimer *timer;
- (instancetype)initWithStartPlayAnimatingWithWeatherStatus:(WEATHERSTATUS)status;

@end
