//
//  TPWeatherForecastView.h
//  实战项目20151205
//
//  Created by Tpy on 15/12/10.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TPWeatherForecastView : UIView

@property (nonatomic, strong) UILabel *weekLabel;
@property (nonatomic, strong) UIImageView *iconView;

@property (nonatomic, strong) UILabel *temperatureLabel;


- (instancetype)initWithFrame:(CGRect)frame;
@end
