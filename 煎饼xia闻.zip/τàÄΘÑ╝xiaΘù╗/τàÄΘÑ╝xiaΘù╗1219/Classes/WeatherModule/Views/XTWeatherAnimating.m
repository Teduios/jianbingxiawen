//
//  XTWeatherAnimating.m
//  实战项目20151205
//
//  Created by tarena on 15/12/15.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "XTWeatherAnimating.h"
#define SNOW_SIZEXY 5
#define RAIN_SIZEXY 3
#define CLOUD_SIZEXY 50
#define SNOW_SPEED 10
#define RAIN_SPEED 3
#define CLOUD_SPEED 40

#define RAIN_OFFSET 60

#define CLOUD_OFFSET 60

@interface XTWeatherAnimating ()
@property (strong, nonatomic) NSArray *imageNameArray;
@property (nonatomic, assign) WEATHERSTATUS status;

@property (nonatomic, assign) float rainOriginX;

@property (nonatomic, assign) float cloudOriginY;
@end
@implementation XTWeatherAnimating
singleton_implementation(XTWeatherAnimating)
- (WEATHERSTATUS)status
{
    if (!_status) {
        _status = CLOUD;
    }
    return _status;
}

- (NSArray *)imageNameArray {
    if(_imageNameArray == nil) {
        _imageNameArray = @[@"snow", @"pull_down_rain_gray", @"ele_sunnyCloud2"];
    }
    return _imageNameArray;
}
- (instancetype)initWithStartPlayAnimatingWithWeatherStatus:(WEATHERSTATUS)status
{
    if (status) {
        self.status = status;
    }
    self = [super init];
    if (self) {
        NSTimeInterval interval;
        switch (self.status) {
            case SNOW:
                interval = .1f;
                break;
            case RAIN:
                interval = .01f;
                break;
            default:
                interval = 5.f;
                break;
        }
        self.timer = [NSTimer scheduledTimerWithTimeInterval:interval target:self selector:@selector(startConfigAnimate) userInfo:nil repeats:YES];
    }
    return self;
}



- (void)startConfigAnimate
{
    [self configImageViewWithWeatherStatus:self.status];
}

- (void)configImageViewWithWeatherStatus:(WEATHERSTATUS)status
{
    NSString *imageName = self.imageNameArray[status-1];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imageName]];
    CGFloat sizeXY;
    CGFloat originX;
    CGFloat originY;
    if (status == SNOW || status == RAIN) {
        originY = TOPLAYOUT_HEIGHT - 20;
        if (status == SNOW) {
            originX = arc4random()%(int)SCREEN_WIDTH;
            sizeXY = arc4random()%SNOW_SIZEXY + SNOW_SIZEXY;
            imageView.frame = CGRectMake(originX, originY, sizeXY, sizeXY);
        } else {
            originX = arc4random()%(int)SCREEN_WIDTH;
            self.rainOriginX = originX;
            sizeXY = arc4random()%RAIN_SIZEXY + RAIN_SIZEXY;
            imageView.frame = CGRectMake(originX, originY, sizeXY, sizeXY);
        }
    } else {
        originX = -3*CLOUD_SIZEXY-155;
        originY = arc4random()%(int)SCREEN_HEIGHT/3.2;
        self.cloudOriginY = originY;
        imageView.frame = CGRectMake(originX, originY, 300, 100);
    }
    imageView.alpha = ((float)(arc4random()%10))/10;
    [self addSubview:imageView];
    [self startAnimateWithWeatherStatus:status andImageView:imageView];
    
}

- (void)startAnimateWithWeatherStatus:(WEATHERSTATUS)status andImageView:(UIImageView *)imageView
{

    [UIView beginAnimations:[NSString stringWithFormat:@"%d", status] context:nil];
    CGFloat sizeXY;
    CGFloat finalX;
    CGFloat finalY;
    if (status == SNOW || status == RAIN) {
        
        finalY = SCREEN_HEIGHT;
        if (status == SNOW) {
            finalX = arc4random()%(int)SCREEN_WIDTH;
            sizeXY = arc4random()%SNOW_SIZEXY + SNOW_SIZEXY;
            [UIView setAnimationDuration:SNOW_SPEED];
            imageView.frame = CGRectMake(finalX, finalY, sizeXY, sizeXY);
        } else {
            int offset = arc4random()%RAIN_OFFSET - arc4random()%RAIN_OFFSET;
            finalX = self.rainOriginX + offset;
            sizeXY = arc4random()%RAIN_SIZEXY + RAIN_SIZEXY;
            [UIView setAnimationDuration:RAIN_SPEED];
            imageView.frame = CGRectMake(finalX, finalY, sizeXY, sizeXY);
        }

    } else {
        finalX = SCREEN_WIDTH+300;
        [UIView setAnimationDuration:CLOUD_SPEED+30];
        
        imageView.frame = CGRectMake(finalX, 100, SCREEN_WIDTH-50, 200);
    }
    [UIView setAnimationDelegate:self];
    [UIView commitAnimations];
}

@end
