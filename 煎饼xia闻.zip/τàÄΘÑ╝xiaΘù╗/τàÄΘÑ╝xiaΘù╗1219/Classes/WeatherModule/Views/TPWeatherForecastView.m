//
//  TPWeatherForecastView.m
//  实战项目20151205
//
//  Created by Tpy on 15/12/10.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "TPWeatherForecastView.h"


@implementation TPWeatherForecastView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
        
        CGFloat font = 0;
        CGFloat width = 0;
        CGFloat height = 0;
        CGFloat iconSize = 0;
        CGFloat iconLabledistance = 0;
        if (CURRENT_DEVICE == 7) {
            font = 16;
            width = 90;
            height = 25;
            iconSize = 60;
            iconLabledistance = 0;
        } else if (CURRENT_DEVICE == 6) {
            font = 13;
            width = 80;
            height = 22;
            iconSize = 55;
            iconLabledistance = -6;
        } else if (CURRENT_DEVICE == 5) {
            font = 13;
            width = 80;
            height = 20;
            iconSize = 50;
            iconLabledistance = -5;
        } else {
            font = 13;
            width = 80;
            height = 15;
            iconSize = 40;
            iconLabledistance = -5;
        }
        
        self.weekLabel = [[UILabel alloc] init];
        self.weekLabel.font = [UIFont systemFontOfSize:font];
        self.weekLabel.textColor = [UIColor whiteColor];
        self.weekLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.weekLabel];
        
        self.iconView = [[UIImageView alloc] init];
        self.iconView.image = [UIImage imageNamed:@"sunny.png"];
        [self addSubview:self.iconView];
        
        self.temperatureLabel = [[UILabel alloc] init];
        self.temperatureLabel.font = [UIFont systemFontOfSize:font];
        self.temperatureLabel.textAlignment = NSTextAlignmentCenter;
        self.temperatureLabel.textColor = [UIColor whiteColor];
        [self addSubview:self.temperatureLabel];
        [self.iconView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.mas_left).with.offset(0);
            make.size.equalTo(@(iconSize));
            make.top.equalTo(self.mas_top).with.offset(0);

        }];
        [self.weekLabel mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.width.equalTo(@(width));
                            make.height.equalTo(@(height));
                            make.top.equalTo(self.mas_top).with.offset(5);
                            make.left.equalTo(self.iconView.mas_right).with.offset(iconLabledistance);

        }];
        [self.temperatureLabel mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.width.equalTo(@(width));
                            make.height.equalTo(@(height));
                            make.top.equalTo(self.weekLabel.mas_bottom).with.offset(0);
                            make.left.equalTo(self.iconView.mas_right).with.offset(iconLabledistance);
        }];

        
    }
    return self;
}


@end
