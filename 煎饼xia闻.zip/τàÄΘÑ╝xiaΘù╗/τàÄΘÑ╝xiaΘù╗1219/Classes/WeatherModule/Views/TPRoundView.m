//
//  TPRoundView.m
//  实战项目20151205
//
//  Created by Tpy on 15/12/9.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "TPRoundView.h"

@implementation TPRoundView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self= [super initWithFrame:frame]) {

        self.layer.masksToBounds = YES;
        self.layer.cornerRadius = 0.5 * self.bounds.size.width;
        self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.3];
        self.userInteractionEnabled = YES;
        
        CGFloat tempHLFont = 0;
        CGFloat tempHLWidth = 0;
        CGFloat weatherIconSize = 0;
        CGFloat windpFont = 0;
        CGFloat downWDWHeight = 0;
        CGFloat currTempFont = 0;
        if (CURRENT_DEVICE == 7) {
            tempHLFont = 14;
            tempHLWidth = 100;
            weatherIconSize = self.bounds.size.width * 0.4;
            windpFont = 16;
            downWDWHeight = 0;
            currTempFont = 40;
        } else if (CURRENT_DEVICE == 6) {
            tempHLFont = 12;
            tempHLWidth = 85;
            weatherIconSize = self.bounds.size.width * 0.4 - 10;
            windpFont = 13;
            downWDWHeight = 1;
            currTempFont = 40;
        } else {
            tempHLFont = 11;
            tempHLWidth = 85;
            weatherIconSize = self.bounds.size.width * 0.4 - 15;
            windpFont = 13;
            downWDWHeight = 3;
            currTempFont = 40;
        }
        

        self.iconView = [UIImageView new];
        [self addSubview:self.iconView];
        [self.iconView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.mas_equalTo(self);
            make.size.mas_equalTo(weatherIconSize);
        }];

        self.humidityLabel = [[UILabel alloc] init];
        self.humidityLabel.textColor = [UIColor whiteColor];
        self.humidityLabel.textAlignment = NSTextAlignmentCenter;
        self.humidityLabel.font = [UIFont fontWithName:@"Helvetica" size:tempHLFont + 2];
        [self addSubview:self.humidityLabel];
        [self.humidityLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.mas_equalTo(self.mas_centerX);
            make.width.mas_equalTo(@100);
            make.height.equalTo(@30);
            make.bottom.equalTo(self.iconView.mas_top).with.offset(10);
        }];
        
        self.tempCurrLabel = [[UILabel alloc] init];
        self.tempCurrLabel.textColor = [UIColor whiteColor];
        self.tempCurrLabel.textAlignment = NSTextAlignmentCenter;
        self.tempCurrLabel.font = [UIFont fontWithName:@"Helvetica-Light" size:currTempFont];
        [self addSubview:self.tempCurrLabel];
        [self.tempCurrLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self.mas_centerX);
            make.width.mas_equalTo(@120);
            make.top.equalTo(self.mas_top).with.offset(10);
            make.bottom.equalTo(self.humidityLabel.mas_top).with.offset(0);
        }];
        
        self.tempHighLabel = [[UILabel alloc] init];
        self.tempHighLabel.textColor = [UIColor whiteColor];
        self.tempHighLabel.textAlignment = NSTextAlignmentCenter;
        self.tempHighLabel.font = [UIFont fontWithName:@"Helvetica" size:tempHLFont];
        [self addSubview:self.tempHighLabel];
        [self.tempHighLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.equalTo(@(tempHLWidth));
            make.height.equalTo(@30);
            make.left.equalTo(self).with.offset(0);
            make.top.equalTo(self).with.offset(self.bounds.size.width/2 - 15);
        }];
        
        self.tempLowLabel = [[UILabel alloc] init];
        self.tempLowLabel.textColor = [UIColor whiteColor];
        self.tempLowLabel.textAlignment = NSTextAlignmentCenter;
        self.tempLowLabel.font = [UIFont fontWithName:@"Helvetica" size:tempHLFont];
        [self addSubview:self.tempLowLabel];
        [self.tempLowLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.equalTo(@(tempHLWidth));
            make.height.equalTo(@30);
            make.right.equalTo(self).with.offset(0);
            make.top.equalTo(self).with.offset(self.bounds.size.width/2 - 15);
        }];
        
        self.windLabel = [[UILabel alloc] init];
        self.windLabel.textColor = [UIColor whiteColor];
        self.windLabel.textAlignment = NSTextAlignmentCenter;
        self.windLabel.font = [UIFont fontWithName:@"Helvetica" size:windpFont];
        [self addSubview:self.windLabel];
        [self.windLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.equalTo(@100);
            make.height.equalTo(@30);
            make.left.equalTo(self).with.offset(0);
            make.top.equalTo(self).with.offset(self.bounds.size.width/2 + 5);
        }];

        self.winpLabel = [[UILabel alloc] init];
        self.winpLabel.textColor = [UIColor whiteColor];
        self.winpLabel.textAlignment = NSTextAlignmentCenter;
        self.winpLabel.font = [UIFont fontWithName:@"Helvetica" size:windpFont];
        [self addSubview:self.winpLabel];
        [self.winpLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.equalTo(@100);
            make.height.equalTo(@30);
            make.right.equalTo(self).with.offset(0);
            make.top.equalTo(self).with.offset(self.bounds.size.width/2 + 5);
        }];

        self.weekLabel = [[UILabel alloc] init];
        self.weekLabel.textColor = [UIColor whiteColor];
        self.weekLabel.textAlignment = NSTextAlignmentCenter;
        self.weekLabel.font = [UIFont fontWithName:@"Helvetica" size:14];
        [self addSubview:self.weekLabel];
        [self.weekLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self.mas_centerX);
            make.width.equalTo(@100);
            make.height.equalTo(@25);
            make.bottom.equalTo(self).with.offset(-10);
        }];

        self.daysLabel = [[UILabel alloc] init];
        self.daysLabel.textColor = [UIColor whiteColor];
        self.daysLabel.textAlignment = NSTextAlignmentCenter;
        self.daysLabel.font = [UIFont fontWithName:@"Helvetica" size:17];
        [self addSubview:self.daysLabel];
        [self.daysLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self.mas_centerX);
            make.width.equalTo(@100);
            make.height.equalTo(@25);
            make.bottom.equalTo(self.weekLabel.mas_top).with.offset(downWDWHeight);
        }];

        self.weatherLabel = [[UILabel alloc] init];
        self.weatherLabel.textColor = [UIColor whiteColor];
        self.weatherLabel.textAlignment = NSTextAlignmentCenter;
        self.weatherLabel.font = [UIFont fontWithName:@"Helvetica" size:14];
        [self addSubview:self.weatherLabel];
        [self.weatherLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(self.mas_centerX);
            make.width.equalTo(@130);
            make.height.equalTo(@25);
            make.bottom.equalTo(self.daysLabel.mas_top).with.offset(downWDWHeight);
        }];
        
        
    }
    return self;
}


@end
