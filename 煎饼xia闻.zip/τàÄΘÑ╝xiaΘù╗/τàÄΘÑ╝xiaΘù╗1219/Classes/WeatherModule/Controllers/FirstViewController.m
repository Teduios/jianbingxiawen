//
//  FirstViewController.m
//  实战项目20151205
//
//  Created by tarena on 15/12/5.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "FirstViewController.h"
#import "TPRoundView.h"
#import "TPWeatherForecastView.h"
#import "TPRequestWeatherDataTool.h"
#import "TPRequestWeatherIconTool.h"
#import "TPWeatherData.h"
#import "TPWeatherIcon.h"
#import <CoreLocation/CoreLocation.h>
#import "TPCityViewController.h"
#import "XTWeatherAnimating.h"
#import "FifthViewController.h"

#define BACKGROUND_DAY     @"pic3"
#define BACKGROUND_NIGHT   @"pic0"

@interface FirstViewController ()<CLLocationManagerDelegate>

@property (nonatomic, strong) NSArray *currIconArray;

@property (nonatomic, strong) TPRoundView *roundView;

@property (nonatomic, strong) UILabel *cityNameLabel;

@property (nonatomic, strong) UIScrollView *bottomScrollView;

@property (nonatomic, strong) NSArray *bottomIconArray;

@property (nonatomic, strong) NSString *cityName;

@property (nonatomic, strong) UIView *animalView;

@property (nonatomic, strong) NSString *locationName;
@property (nonatomic, strong) CLLocationManager *manager;
@property (nonatomic, strong) CLGeocoder *geocoder;

@property (nonatomic, assign) CGFloat currentCenterY;

@property (nonatomic, strong) XTGuideViewTool *tool;

@property (nonatomic, strong) UIImageView *bkImageView;
@end

@implementation FirstViewController

- (CLGeocoder *)geocoder {
    if (!_geocoder) {
        _geocoder = [[CLGeocoder alloc] init];
    }
    return _geocoder;
}

- (NSArray *)currIconArray {
    if (!_currIconArray) {
        _currIconArray = [TPRequestWeatherIconTool weatherIcon];
    }
    return _currIconArray;
}

- (NSArray *)bottomIconArray {
    if (!_bottomIconArray) {
        _bottomIconArray = [TPRequestWeatherIconTool weatherIcon];
    }
    return _bottomIconArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    XTGuideViewTool *tool = [XTGuideViewTool showGuideView];
    UIImageView *imageView1 = [[UIImageView alloc] init];
    imageView1.image = [UIImage imageNamed:@"Weather_pull_refresh"];
    UIImageView *imageView2 = [UIImageView new];
    imageView2.image = [UIImage imageNamed:@"Weather_scrollBar"];
    UIImageView *imageView3 = [UIImageView new];
    imageView3.image = [UIImage imageNamed:@"Weather_city_selection"];
    if (CURRENT_DEVICE == 7) {
        imageView1.frame = CGRectMake(100, SCREEN_HEIGHT/2-130, 400, 225);
        imageView2.frame = CGRectMake(0, SCREEN_HEIGHT - 250, 400, 225);
        imageView3.frame = CGRectMake(-30, 55, 400, 225);
    } else if (CURRENT_DEVICE == 6) {
        imageView1.frame = CGRectMake(50, SCREEN_HEIGHT/2-100, 400, 225);
        imageView2.frame = CGRectMake(0, SCREEN_HEIGHT - 250, 400, 225);
        imageView3.frame = CGRectMake(-30, 55, 400, 225);
    } else if(CURRENT_DEVICE == 5) {
        imageView1.frame = CGRectMake(20, SCREEN_HEIGHT/2-80, 300, 200);
        imageView2.frame = CGRectMake(20, SCREEN_HEIGHT - 210, 300, 180);
        imageView3.frame = CGRectMake(-30, 55, 400, 225);
    } else {
        imageView1.frame = CGRectMake(80, SCREEN_HEIGHT/2-70, 300, 150);
        imageView2.frame = CGRectMake(10, SCREEN_HEIGHT - 180, 300, 150);
        imageView3.frame = CGRectMake(-15, 50, 300, 225);
    }
    [tool.guideImageView addSubview:imageView1];
    [tool.guideImageView addSubview:imageView2];
    [tool.guideImageView addSubview:imageView3];
    self.tool = tool;
    
    [self setupBackground];
    [self setupRoundView];
    [self setupWeatherForecastView];
    [self startUpdataLocation];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(cityDidChange:) name:@"TPCityChange" object:nil];

    UIPanGestureRecognizer *panGR = [[UIPanGestureRecognizer alloc]initWithTarget:self action:@selector(pan:)];
    [self.roundView addGestureRecognizer:panGR];

    CGFloat y1 = self.roundView.frame.origin.y;
    CGFloat y2 = self.roundView.bounds.size.height/2;
    self.currentCenterY = y1 + y2;

}
#pragma mark ---- 下拉手势
- (void)pan:(UIPanGestureRecognizer *)gr
{
    BOOL request = NO;
    
    CGFloat moveDistance;
    if (CURRENT_DEVICE == 7) {
        moveDistance = 80.f;
    } else if (CURRENT_DEVICE == 6) {
        moveDistance = 70.f;
    } else if (CURRENT_DEVICE == 5) {
        moveDistance = 60.f;
    } else {
        moveDistance = 30.f;
    }
    CGPoint point = [gr translationInView:self.roundView];
    if (point.y < moveDistance) {
        self.roundView.center = CGPointMake(self.roundView.center.x, point.y+self.currentCenterY);
        [self.view layoutIfNeeded];
    }
    if (point.y > moveDistance) {
        request = YES;
    }
    if (gr.state == UIGestureRecognizerStateEnded) {
        if (request == YES) {
            request = NO;
            [self getJSONFormServer];
        }
        [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
            self.roundView.center = CGPointMake(SCREEN_WIDTH/2, self.currentCenterY);
        } completion:nil];
    }
}
#pragma mark ---- 接收通知
- (void)cityDidChange:(NSNotification *)notification {
    NSString *cityName = notification.userInfo[@"TPSelectedCityName"];
    [self.manager stopUpdatingLocation];
    self.cityName = cityName;
    [self getJSONFormServer];
}

- (void)startUpdataLocation {
    self.manager = [[CLLocationManager alloc] init];
    self.manager.delegate = self;
    if ([[UIDevice currentDevice].systemVersion doubleValue] > 8.0) {
        [self.manager requestWhenInUseAuthorization];
    } else {
        [self.manager startUpdatingLocation];
    }
}
#pragma mark --- CLLocationManagerDelegate
- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status {
    switch (status) {
        case kCLAuthorizationStatusAuthorizedWhenInUse:
            self.manager.desiredAccuracy = kCLLocationAccuracyBest;
            [self.manager startUpdatingLocation];
            [MBProgressHUD hideHUD];
            [MBProgressHUD showMessage:@"正在定位,请稍后..."];
            break;
        case kCLAuthorizationStatusDenied:
            self.locationName = nil;
            [self getJSONFormServer];
            break;
        default:
            break;
    }
}
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations {
    CLLocation *location = [locations lastObject];
    [self.geocoder reverseGeocodeLocation:location completionHandler:^(NSArray<CLPlacemark *> * _Nullable placemarks, NSError * _Nullable error) {
        if (!error) {
            CLPlacemark *placemark = [placemarks firstObject];
            NSString *cityNM = placemark.addressDictionary[@"City"];
            self.locationName = [cityNM substringToIndex:cityNM.length - 1];
            if (self.locationName.length > 1) {
                self.cityName = self.locationName;
                [MBProgressHUD hideHUD];
            } else {
                [MBProgressHUD hideHUD];
                self.cityName = @"上海";
            }
            [MBProgressHUD hideHUD];
            [self getJSONFormServer];
        }
    }];
    [self.manager stopUpdatingLocation];
}

#pragma mark ---- 初始化背景
- (void)setupBackground {
    self.view.backgroundColor = [UIColor whiteColor];
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"HH"];
    NSString *str = [formatter stringFromDate:[NSDate date]];
    int time = [str intValue];
    self.bkImageView = [[UIImageView alloc]init];
    self.bkImageView.frame = [UIScreen mainScreen].bounds;
    if (time>=18 || time<=6) {
        self.bkImageView.image = [UIImage imageNamed:BACKGROUND_NIGHT];
    } else {
        self.bkImageView.image = [UIImage imageNamed:BACKGROUND_DAY];
    }
    [self.view addSubview:self.bkImageView];
    [self.bkImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view).with.insets(UIEdgeInsetsMake(0,0,0,0));
    }];
    CGFloat cityFont = 0;
    CGFloat topDistance = 0;
    if (CURRENT_DEVICE == 7) {
        cityFont = 22;
        topDistance = TOPLAYOUT_HEIGHT + 20;
    } else if (CURRENT_DEVICE == 6) {
        cityFont = 22;
        topDistance = TOPLAYOUT_HEIGHT + 20;
    } else if(CURRENT_DEVICE == 5) {
        cityFont = 22;
        topDistance = TOPLAYOUT_HEIGHT + 20;
    } else {
        cityFont = 16;
        topDistance = TOPLAYOUT_HEIGHT + 14;
    }
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setImage:[UIImage imageNamed:@"NavBarIconSearch_white"] forState:UIControlStateNormal];
    [self.view addSubview:button];
    [button mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(topDistance);
        make.width.and.height.mas_equalTo(30);
        make.left.mas_equalTo(self.view).with.offset(20);
    }];
    [button addTarget:self action:@selector(gotoCityList) forControlEvents:UIControlEventTouchUpInside];
    self.cityNameLabel = [[UILabel alloc]init];
    self.cityNameLabel.textColor = [UIColor whiteColor];
    self.cityNameLabel.textAlignment = NSTextAlignmentLeft;
    self.cityNameLabel.font = [UIFont fontWithName:@"Helvetica" size:cityFont];
    [self.view addSubview:self.cityNameLabel];
    [self.cityNameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.view).with.offset(topDistance);
        make.width.equalTo(@200);
        make.height.equalTo(@30);
        make.left.equalTo(button.mas_right).with.offset(0);
    }];
}
- (void)gotoCityList {
    [self.manager stopUpdatingLocation];
    TPCityViewController *cityViewController = [[TPCityViewController alloc] init];
    cityViewController.modalPresentationStyle = UIModalPresentationFormSheet;
    [self.navigationController pushViewController:cityViewController animated:YES];
}
#pragma mark ---- 初始化圆形模糊视图
- (void)setupRoundView {
    CGFloat diameter = 0;
    CGFloat topDistance = 0;
    if (CURRENT_DEVICE == 7) {
        diameter = SCREEN_WIDTH - 110;
        topDistance = TOPLAYOUT_HEIGHT + diameter/2 + 50;
    } else if (CURRENT_DEVICE == 6) {
        diameter = SCREEN_WIDTH - 110;
        topDistance = TOPLAYOUT_HEIGHT + diameter/2 + 50;
    } else if (CURRENT_DEVICE == 5) {
        diameter = SCREEN_WIDTH - 85;
        topDistance = TOPLAYOUT_HEIGHT + diameter/2 + 50;
    } else {
        diameter = SCREEN_WIDTH - 100;
        topDistance = TOPLAYOUT_HEIGHT + diameter/2 + 40;
    }
    self.roundView = [[TPRoundView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH/2, topDistance, diameter, diameter)];
    self.roundView.center = CGPointMake(SCREEN_WIDTH/2, topDistance);
    [self.view addSubview:self.roundView];
}
#pragma mark ---- 初始化底部天气预报
- (void)setupWeatherForecastView {
    CGFloat width = 0;
    CGFloat height = 0;
    if (CURRENT_DEVICE == 7) {
        width = 155;
        height = 65;
    } else if (CURRENT_DEVICE == 6) {
        width = 130;
        height = 57;
    } else if (CURRENT_DEVICE == 5) {
        width = 130;
        height = 55;
    } else {
        width = 115;
        height = 40;
    }
    UIScrollView *scrollView = [[UIScrollView alloc] init];
    self.bottomScrollView = scrollView;
    scrollView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:scrollView];
    scrollView.frame = CGRectMake(0, self.view.frame.size.height-49-height, self.view.frame.size.width, height);
    scrollView.contentSize = CGSizeMake(7*width, scrollView.frame.size.height);
    for (int i = 0; i < 7; i++) {
        TPWeatherForecastView *view = [[TPWeatherForecastView alloc] initWithFrame:CGRectMake(i*width, 0, width, scrollView.frame.size.height)];
        view.tag = i+1;
        [scrollView addSubview:view];
    }
}
#pragma mark ---- 数据解析
- (void)getJSONFormServer {
    self.animalView = nil;
    [MBProgressHUD hideHUD];
    [MBProgressHUD showMessage:@"正在加载数据..."];
    [[XTWeatherAnimating sharedXTWeatherAnimating].timer invalidate];
    [TPRequestWeatherDataTool requestWithData:@"weather.today" andCityName:self.cityName isCurrent:YES parsedCompletion:^(id type) {
        TPWeatherData *model = type;
        if (model.msg) {
            [MBProgressHUD hideHUD];
            [MBProgressHUD showError:@"查询失败,请重新选择城市"];
        } else {
            self.roundView.daysLabel.text = model.days;
            self.roundView.weekLabel.text = model.week;
            self.roundView.tempCurrLabel.text = model.temperature_curr;
            self.roundView.humidityLabel.text = [NSString stringWithFormat:@"湿度:%@", model.humidity];
            self.roundView.weatherLabel.text = model.weather;
            self.roundView.windLabel.text = model.wind;
            self.roundView.winpLabel.text = [NSString stringWithFormat:@"风力:%@",model.winp];
            self.roundView.tempHighLabel.text = [NSString stringWithFormat:@"最高气温:%@˚C",model.temp_high];
            self.roundView.tempLowLabel.text = [NSString stringWithFormat:@"最低气温:%@˚C",model.temp_low];
            self.cityNameLabel.text = model.citynm;
            [self.view layoutIfNeeded];
        }
        NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
        [formatter setDateFormat:@"HH"];
        NSString *str = [formatter stringFromDate:[NSDate date]];
        int time = [str intValue];
        for (int i = 0; i < self.currIconArray.count; i++) {
            TPWeatherIcon *icon = self.currIconArray[i];
            if ([model.weatid isEqualToString:[NSString stringWithFormat:@"%@", icon.weatid]]) {
                if (time>=18||time<=06) {
                    self.roundView.iconView.image = [UIImage imageNamed:[NSString stringWithFormat:@"weather_icon_night%@", icon.weather_icon]];
                }
                else{
                    self.roundView.iconView.image = [UIImage imageNamed:[NSString stringWithFormat:@"weather_icon_day%@", icon.weather_icon]];
                }
            }
        }
        if ((model.weatid.intValue >= 4 && model.weatid.intValue <=13)||(model.weatid.intValue == 20) || (model.weatid.intValue >= 22 && model.weatid.intValue <= 26)) {
            self.animalView = [[XTWeatherAnimating alloc]initWithStartPlayAnimatingWithWeatherStatus:RAIN];
        } else if ((model.weatid.intValue >= 14 && model.weatid.intValue <= 18) || (model.weatid.intValue >= 27 && model.weatid.intValue <= 29)) {
            self.animalView = [[XTWeatherAnimating alloc]initWithStartPlayAnimatingWithWeatherStatus:SNOW];
        } else {
            self.animalView = [[XTWeatherAnimating alloc]initWithStartPlayAnimatingWithWeatherStatus:CLOUD];
        }
        [self.bkImageView addSubview:self.animalView];
    }];
    [TPRequestWeatherDataTool requestWithData:@"weather.future" andCityName:self.cityName isCurrent:NO parsedCompletion:^(id object) {
        [MBProgressHUD hideHUD];
        NSArray *weathers = (NSArray *)object;
        for (int i = 0; i < weathers.count; i++) {
            TPWeatherForecastView *view = [self.bottomScrollView viewWithTag:i+1];
            TPWeatherData *weather = weathers[i];
            if (i == 0) {
                view.weekLabel.text = @"今 天";
            } else {
                view.weekLabel.text = weather.week;
            }
            view.temperatureLabel.text = weather.temperature;
            if ((weather.weatid.intValue < 1) || (weather.weatid.intValue > 33)) {
                view.iconView.image = [UIImage imageNamed:@"weather_icon_bottom0"];
            }
            for (int j = 0; j < self.bottomIconArray.count; j++){
                TPWeatherIcon *icon = self.bottomIconArray[j];
                if ([weather.weatid isEqualToString:[NSString stringWithFormat:@"%@", icon.weatid]]) {
                    view.iconView.image = [UIImage imageNamed:[NSString stringWithFormat:@"weather_icon_bottom%@", icon.weather_icon]];
                }
            }
        }
    }];
}
#pragma mark ---- 当视图将要出现时
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden = NO;
    [self shouldChangeTheme];
}
#pragma mark ---- ChangeTheme
- (void)shouldChangeTheme {
    BOOL status = [FifthViewController sharedFifthViewController].ThemeSwitchStatus;
    if (status) {
        self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
        self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
        [self.view layoutIfNeeded];
    } else {
        self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
        self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
        [self.view layoutIfNeeded];
    }
}

@end
