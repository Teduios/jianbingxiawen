//
//  TPCityViewController.m
//  实战项目20151205
//
//  Created by Tpy on 15/12/15.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "TPCityViewController.h"
#import "TPRequestWeatherIconTool.h"
#import "TPCityGroup.h"

@interface TPCityViewController()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *cityGroupsArray;
@end
@implementation TPCityViewController
- (NSArray *)cityGroupsArray {
    if (!_cityGroupsArray) {
        _cityGroupsArray = [TPRequestWeatherIconTool cityGroups];
    }
    return _cityGroupsArray;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"城市列表";
    self.tableView=[[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStyleGrouped];
    self.tableView.dataSource=self;
    self.tableView.delegate = self;
    [self.view addSubview:_tableView];
    self.view.backgroundColor = [UIColor whiteColor];
}
#pragma mark --- TableViewDataSourceDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.cityGroupsArray.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    TPCityGroup *cityGroup = self.cityGroupsArray[section];
    return cityGroup.cities.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    TPCityGroup *cityGroup = self.cityGroupsArray[indexPath.section];
    cell.textLabel.text = cityGroup.cities[indexPath.row];
    
    return cell;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    TPCityGroup *cityGroup = self.cityGroupsArray[section];
    return cityGroup.title;
}
- (NSArray<NSString *> *)sectionIndexTitlesForTableView:(UITableView *)tableView {
    return [self.cityGroupsArray valueForKeyPath:@"title"];
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    TPCityGroup *cityGroup = self.cityGroupsArray[indexPath.section];
    NSString *cityName = cityGroup.cities[indexPath.row];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"TPCityChange" object:self userInfo:@{@"TPSelectedCityName":cityName}];
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark 设置分组标题内容高度
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if(section==0){
        return 40;
    }
    return 15;
}
#pragma mark 设置每行高度（每行高度可以不一样）
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 45;
}



@end
