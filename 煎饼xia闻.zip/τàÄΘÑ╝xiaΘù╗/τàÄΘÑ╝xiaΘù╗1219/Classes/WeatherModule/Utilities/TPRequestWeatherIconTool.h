//
//  TPRequestWeatherIconTool.h
//  TPWeather
//
//  Created by Tpy on 15/12/6.
//  Copyright © 2015年 tpy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TPRequestWeatherIconTool : NSObject

+ (NSArray *)weatherIcon;

+ (NSArray *)cityGroups;
@end
