//
//  TPRequestWeatherDataTool.m
//  TPWeather
//
//  Created by Tpy on 15/12/6.
//  Copyright © 2015年 tpy. All rights reserved.
//

#import "TPRequestWeatherDataTool.h"
#import "TPWeatherData.h"

@implementation TPRequestWeatherDataTool

+ (void)requestWithData:(NSString *)data andCityName:(NSString *)cityName isCurrent:(BOOL)isCurrent parsedCompletion:(myBlock)myBlock {
    
    NSString *urlStr = WEATHER_URL;
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"app"] = data;
    parameters[@"weaid"] = cityName;
    parameters[@"appkey"] = WEATHER_APPKEY;
    parameters[@"sign"] = WEATHER_SIGN;
    parameters[@"format"] = WEATHER_FORMAT;
    
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    
    [manager GET:urlStr parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (isCurrent) {
            NSDictionary *currentDic = responseObject;
            TPWeatherData *currentWeather = [self parseCurrentWeatherDic:currentDic];
            myBlock(currentWeather);
        } else {
            NSDictionary *forecastDic = responseObject;
            TPWeatherData *forecastWeather = [self parseForecastWeatherDic:forecastDic];
            myBlock(forecastWeather);
        }

    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
    }];
}
+ (TPWeatherData *)parseCurrentWeatherDic:(NSDictionary *)currentDic {
    
    TPWeatherData *model = [TPWeatherData new];
    model.success = currentDic[@"success"];
    model.msg = currentDic[@"msg"];
    model.days = currentDic[@"result"][@"days"];
    model.week = currentDic[@"result"][@"week"];
    model.citynm = currentDic[@"result"][@"citynm"];
    model.temperature = currentDic[@"result"][@"temperature"];
    model.temperature_curr = currentDic[@"result"][@"temperature_curr"];
    model.humidity = currentDic[@"result"][@"humidity"];
    model.weather = currentDic[@"result"][@"weather"];
    model.weather_icon = currentDic[@"result"][@"weather_icon"];
    model.weather_icon1 = currentDic[@"result"][@"weather_icon1"];
    model.wind = currentDic[@"result"][@"wind"];
    model.winp = currentDic[@"result"][@"winp"];
    model.temp_high = currentDic[@"result"][@"temp_high"];
    model.temp_low = currentDic[@"result"][@"temp_low"];
    model.weatid = currentDic[@"result"][@"weatid"];
    
    return model;
}
+ (TPWeatherData *)parseForecastWeatherDic:(NSDictionary *)forecastDic {
    
    NSArray *array = forecastDic[@"result"];
    NSMutableArray *mutableArray = [NSMutableArray array];
    for (int i = 0; i < array.count; i++) {
        TPWeatherData *model = [TPWeatherData new];
        model.days = forecastDic[@"result"][i][@"days"];
        model.week = forecastDic[@"result"][i][@"week"];
        model.citynm = forecastDic[@"result"][i][@"citynm"];
        model.temperature = forecastDic[@"result"][i][@"temperature"];
        model.humidity = forecastDic[@"result"][i][@"humidity"];
        model.weather = forecastDic[@"result"][i][@"weather"];
        model.weather_icon = forecastDic[@"result"][i][@"weather_icon"];
        model.weather_icon1 = forecastDic[@"result"][i][@"weather_icon1"];
        model.wind = forecastDic[@"result"][i][@"wind"];
        model.winp = forecastDic[@"result"][i][@"winp"];
        model.temp_high = forecastDic[@"result"][i][@"temp_high"];
        model.temp_low = forecastDic[@"result"][i][@"temp_low"];
        model.weatid = forecastDic[@"result"][i][@"weatid"];
        [mutableArray addObject:model];
    }
    return [mutableArray copy];
}


@end
