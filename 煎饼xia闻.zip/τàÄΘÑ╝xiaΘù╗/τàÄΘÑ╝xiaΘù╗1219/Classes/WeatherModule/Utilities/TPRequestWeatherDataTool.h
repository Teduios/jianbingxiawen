//
//  TPRequestWeatherDataTool.h
//  TPWeather
//
//  Created by Tpy on 15/12/6.
//  Copyright © 2015年 tpy. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^myBlock)(id type);

@interface TPRequestWeatherDataTool : NSObject

+ (void)requestWithData:(NSString *)data andCityName:(NSString *)cityName isCurrent:(BOOL)isCurrent parsedCompletion:(myBlock)myBlock;


@end
