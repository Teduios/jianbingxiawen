//
//  TPRequestWeatherIconTool.m
//  TPWeather
//
//  Created by Tpy on 15/12/6.
//  Copyright © 2015年 tpy. All rights reserved.
//

#import "TPRequestWeatherIconTool.h"
#import "TPWeatherIcon.h"
#import "TPCityGroup.h"

@implementation TPRequestWeatherIconTool

static NSArray *_weatherIconArray = nil;
+ (NSArray *)weatherIcon {
    if (!_weatherIconArray) {
        _weatherIconArray = [[self alloc] getAndParseWithPlistFile:@"weatherIcon.plist" withClass:[TPWeatherIcon class]];
    }
    return _weatherIconArray;
}

- (NSArray *)getAndParseWithPlistFile:(NSString *)plistFile withClass:(Class)className {
    NSString *bundlePath = [[NSBundle mainBundle] pathForResource:@"Battercake" ofType:@"bundle"];
    NSString *plistPath = [[NSBundle bundleWithPath:bundlePath]pathForResource:plistFile ofType:nil];
    NSArray *array = [NSArray arrayWithContentsOfFile:plistPath];
    NSMutableArray *mutableArray = [NSMutableArray array];
    for (NSDictionary *dic in array) {
        id instance = [className new];
        [instance setValuesForKeysWithDictionary:dic];
        [mutableArray addObject:instance];
    }
    return [mutableArray copy];
}

static NSArray *_cityGroupsArray = nil;
+ (NSArray *)cityGroups {
    if (!_cityGroupsArray) {
        _cityGroupsArray = [[self alloc] getAndParseWithPlistFile:@"cityGroups.plist" withClass:[TPCityGroup class]];
    }
    return _cityGroupsArray;
}

@end
