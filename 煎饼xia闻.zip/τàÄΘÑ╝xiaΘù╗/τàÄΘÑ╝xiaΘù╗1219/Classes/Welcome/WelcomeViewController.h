//
//  customViewController.h
//  testWelcomePages
//
//  Created by tarena on 15/12/14.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "IFTTTAnimatedPagingScrollViewController.h"

@interface WelcomeViewController : IFTTTAnimatedPagingScrollViewController

singleton_interface(WelcomeViewController)

@end
