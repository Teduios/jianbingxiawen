//
//  FifthTableViewController.h
//  实战项目20151205
//
//  Created by tarena on 15/12/10.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Singleton.h"
@interface FifthViewController : UITableViewController

singleton_interface(FifthViewController)


@property (assign, nonatomic) BOOL ThemeSwitchStatus;

@property (assign, nonatomic) BOOL LongPressSwitchStatus;

@end
