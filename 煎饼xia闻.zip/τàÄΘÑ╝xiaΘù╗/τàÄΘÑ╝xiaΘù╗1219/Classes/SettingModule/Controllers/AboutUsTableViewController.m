//
//  AboutUsTableViewController.m
//  实战项目20151205
//
//  Created by tarena on 15/12/16.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "AboutUsTableViewController.h"
#import "MainTabBarViewController.h"
#import "FORIntroInfo.h"

#define DAY_TIME_BACKGROUNDIMAGE_NAME @"pic42"
#define NIGHT_BACKGROUNDIMAGE_NAME @"pic13"
@interface AboutUsTableViewController ()

@property (strong, nonatomic) UIImageView *backGoundImageView;
@property (strong, nonatomic) NSArray *introArray;

@end

@implementation AboutUsTableViewController

- (NSArray *)introArray {
    if (!_introArray) {
        _introArray = [FORIntroInfo parseIntroduction];
    }
    return _introArray;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self shouldChangeTheme];
}
#pragma mark----ChangeTheme
- (void)shouldChangeTheme {
    BOOL status = [FifthViewController sharedFifthViewController].ThemeSwitchStatus;
    if (status) {
        self.navigationController.navigationBar.barStyle  = UIBarStyleBlack;
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
        self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
        self.tableView.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:NIGHT_BACKGROUNDIMAGE_NAME]];
        
    } else {
        self.navigationController.navigationBar.barStyle  = UIBarStyleDefault;
        self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
        self.tableView.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:DAY_TIME_BACKGROUNDIMAGE_NAME]];
    }
    self.navigationItem.title = @"关于我们";
    self.tabBarController.tabBar.hidden = YES;
    self.tableView.tableFooterView = [UIView new];
    CGFloat spaceInset;
    if (CURRENT_DEVICE == 4) {
        spaceInset = 20;
    } else if (CURRENT_DEVICE == 5) {
        spaceInset = 20;
    } else if (CURRENT_DEVICE == 6) {
        spaceInset = 35;
    } else {
        spaceInset = 45;
    }
    self.tableView.sectionHeaderHeight = spaceInset;
    self.tableView.userInteractionEnabled = NO;
    self.tableView.estimatedRowHeight = 44;
    self.tableView.backgroundColor = [UIColor clearColor];
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [MainTabBarViewController sharedMainTabBarViewController].centerIV.hidden = YES;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.introArray.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IntroCell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"IntroCell"];
    }
    FORIntroInfo *info = self.introArray[indexPath.section];
    NSString *content = [info.response stringByAppendingString:@"."];
    cell.textLabel.text = content;
    cell.textLabel.font = [UIFont fontWithName:@"Courier-Bold" size:18];
    cell.textLabel.numberOfLines = 0;
    cell.textLabel.textColor = [UIColor whiteColor];
    cell.backgroundColor = [UIColor clearColor];
    
    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UILabel *label = [UILabel new];
    label.backgroundColor = [UIColor clearColor];
    label.frame = CGRectMake(0, 0, SCREEN_WIDTH, 10);
    return label;
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.tabBarController.tabBar.hidden = NO;
    [MainTabBarViewController sharedMainTabBarViewController].centerIV.hidden = NO;
}

@end
