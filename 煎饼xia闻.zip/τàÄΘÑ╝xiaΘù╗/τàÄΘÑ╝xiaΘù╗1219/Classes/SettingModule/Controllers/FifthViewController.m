//
//  FifthTableViewController.m
//  实战项目20151205
//
//  Created by tarena on 15/12/10.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "FifthViewController.h"
#import "Masonry.h"
#import "FORSetTableViewCell.h"
#import "AboutUsTableViewController.h"
#import "SDImageCache.h"
#import "WelcomeViewController.h"

#define DAY_TIME_BACKGROUNDIMAGE_NAME @"58"
#define NIGHT_BACKGROUNDIMAGE_NAME @"58"
@interface SystemCell : UITableViewCell



@end
@implementation SystemCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:reuseIdentifier]) {
        self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    return self;
}

@end
@interface FifthViewController ()<FORSetTableViewCellDelegate>

@end

@implementation FifthViewController

singleton_implementation(FifthViewController)

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"设置";
    [self setTableVeiw];
}

- (void)setTableVeiw {
    
    self.tableView.tableFooterView = [UIView new];
    self.tableView.estimatedRowHeight = 54;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.backgroundColor = [UIColor whiteColor];
    self.tableView.scrollEnabled = YES;
    self.tableView.sectionHeaderHeight = 40;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;

}

- (void)fORSetTableViewCell:(FORSetTableViewCell *)tableViewCell withSwitch:(UISwitch *)swh {
    if (swh.tag == 101) {
        [self changeAllThemeWithTheme:swh];
    } else if (swh.tag == 102) {
        if (swh.on == YES) {
            self.LongPressSwitchStatus = YES;
        } else {
            self.LongPressSwitchStatus = NO;
        }
    }
}

- (void)changeAllThemeWithTheme:(UISwitch *)swh {
    if (swh.on == YES) {
        
        self.navigationController.navigationBar.barStyle = UIBarStyleBlack;
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
        self.tabBarController.tabBar.barTintColor = [UIColor blackColor];
        self.ThemeSwitchStatus = YES;

    } else {
        
        self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
        self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
        self.tabBarController.tabBar.barTintColor = [UIColor whiteColor];
        self.ThemeSwitchStatus = NO;

    }
}

#pragma mark--------UITableViewDelegate/DataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 4;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case 0:
            return 1;
            break;
        case 1:
            return 2;
            break;
        case 2:
            return 1;
        default:
            return 1;
            break;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FORSetTableViewCell *cell1 = [[FORSetTableViewCell alloc] init];
    cell1.backgroundColor = [UIColor clearColor];
    cell1.selectedBackgroundView = [[UIView alloc] initWithFrame:cell1.frame];
    cell1.selectedBackgroundView.backgroundColor = [UIColor clearColor];
    cell1.delegate = self;
    
    SystemCell *cell2 = [[SystemCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
    cell2.backgroundColor = [UIColor clearColor];
    cell2.selectedBackgroundView = [[UIView alloc] initWithFrame:cell2.frame];
    cell2.selectedBackgroundView.backgroundColor = [UIColor clearColor];
    cell2.textLabel.font = [UIFont boldSystemFontOfSize:18];
    
    switch (indexPath.section) {
        case 0:
            cell2.textLabel.text = @"给手机抽个脂(清除缓存)";
            return cell2;
            break;
        case 1:
            if (indexPath.row == 0) {
                cell1.titlelabel.text = @"试试换一个风格";
                cell1.cellSwitch.tag = 101;
                return cell1;
            } else if (indexPath.row == 1) {
                cell1.titlelabel.text = @"长按新闻标题朗读";
                cell1.cellSwitch.on = NO;
                cell1.cellSwitch.tag = 102;
                return cell1;
            }
            break;
        case 2:
                cell2.textLabel.text = @"关于我们";
                return  cell2;
            break;
        default:
            cell2.textLabel.text = @"欢迎页界面";
            return cell2;
            break;
    }
    return nil;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        UILabel *label = [UILabel new];
        
        label.text = @"嘘！不许笑！我们正设置呢~O(∩_∩)O~";
        label.textColor = [UIColor lightGrayColor];
        label.font = [UIFont italicSystemFontOfSize:17];
        label.frame = CGRectMake(16, 0, 200, 20);
        label.textAlignment = NSTextAlignmentCenter;
        
        return label;
    }
    return nil;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        [[SDImageCache sharedImageCache] clearDisk];
        [MBProgressHUD showSuccess:@"清除缓存成功"];
    } else if (indexPath.section == 2) {
            AboutUsTableViewController *aboutVC = [[AboutUsTableViewController alloc] init];
            [self.navigationController pushViewController:aboutVC animated:YES];
    } else if (indexPath.section == 3 ) {
      WelcomeViewController *welcomeVC = [WelcomeViewController sharedWelcomeViewController];
    welcomeVC.pageOffset = 0.f;
    [UIApplication sharedApplication].keyWindow.rootViewController = welcomeVC;  
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return 44;
    } else {
        return 22;
    }
}
@end
