//
//  FORSetTableViewCell.m
//  实战项目20151205
//
//  Created by tarena on 15/12/10.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "FORSetTableViewCell.h"
#import "Masonry.h"

@implementation FORSetTableViewCell

- (instancetype)init {
    if (self = [super init]) {
        
        self.separatorInset = UIEdgeInsetsMake(1, 1, 2, 2);
        self.userInteractionEnabled = YES;
        
        _titlelabel = [UILabel new];
        _titlelabel.font = [UIFont boldSystemFontOfSize:18];
        [self addSubview:_titlelabel];
        __weak typeof(self) wself = self;
        CGFloat padding = 10.0;
        [_titlelabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(wself.mas_top).with.offset(padding);
            make.left.equalTo(wself.mas_left).with.offset(16);
            make.bottom.equalTo(wself.mas_bottom).with.offset(-padding);
            make.width.equalTo(@200.0);
            make.height.equalTo(@24);
        }];
        _cellSwitch = [[UISwitch alloc] init];
        _cellSwitch.on = NO;
        _cellSwitch.onTintColor = [UIColor colorWithRed:17.0/255.0 green:190.0/255.0 blue:227.0/255.0 alpha:1.0];
        [_cellSwitch addTarget:self action:@selector(setNavigationBarAndTabBarThemeWithSwitchStatus) forControlEvents:UIControlEventValueChanged];
        
        [self addSubview:_cellSwitch];
        [_cellSwitch mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(wself.mas_top).with.offset(8.0);
            make.right.equalTo(wself.mas_right).with.offset(-2 * padding);
        }];
    }
    return self;
}
- (void)setNavigationBarAndTabBarThemeWithSwitchStatus{
    
    [self.delegate fORSetTableViewCell:self withSwitch:self.cellSwitch];
    
}


@end
