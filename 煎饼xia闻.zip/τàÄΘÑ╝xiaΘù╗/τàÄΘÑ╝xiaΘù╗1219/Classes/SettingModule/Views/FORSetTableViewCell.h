//
//  FORSetTableViewCell.h
//  实战项目20151205
//
//  Created by tarena on 15/12/10.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FORSetTableViewCell;
@protocol  FORSetTableViewCellDelegate <NSObject>

- (void)fORSetTableViewCell:(FORSetTableViewCell *)tableViewCell withSwitch:(UISwitch *)swh;

@end

@interface FORSetTableViewCell : UITableViewCell

@property (strong, nonatomic) UILabel *titlelabel;
@property (strong, nonatomic) UISwitch *cellSwitch;

@property (weak, nonatomic) id<FORSetTableViewCellDelegate> delegate;

@end
