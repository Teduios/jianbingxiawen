//
//  FORIntroInfo.m
//  煎饼xia闻1219
//
//  Created by tarena on 15/12/20.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "FORIntroInfo.h"
#import "FMDatabase.h"
#import "FORIntroManager.h"

@implementation FORIntroInfo

+ (NSArray *)parseIntroduction {
    FMDatabase *database = [FORIntroManager sharedDatabase];
    FMResultSet *resultSet = [database executeQuery:@"select * from intro"];
    NSMutableArray *mutableArray = [NSMutableArray array];
    while ([resultSet next]) {
        FORIntroInfo *intro = [FORIntroInfo new];
        intro.name = [resultSet stringForColumn:@"NAME"];
        intro.response = [resultSet stringForColumn:@"RESPONSE"];
        [mutableArray addObject:intro];
    }
    [database closeOpenResultSets];
    [database close];
    
    return [mutableArray copy];
}

@end
