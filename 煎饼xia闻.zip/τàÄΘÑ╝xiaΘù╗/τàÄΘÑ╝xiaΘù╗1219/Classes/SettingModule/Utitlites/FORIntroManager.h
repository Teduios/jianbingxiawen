//
//  FORIntroManager.h
//  煎饼xia闻1219
//
//  Created by tarena on 15/12/20.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"

@interface FORIntroManager : NSObject

+ (FMDatabase *)sharedDatabase;

@end
