//
//  FORIntroManager.m
//  煎饼xia闻1219
//
//  Created by tarena on 15/12/20.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "FORIntroManager.h"

@implementation FORIntroManager

+ (FMDatabase *)sharedDatabase {
    static FMDatabase *database = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSString *bundlePath = [[NSBundle mainBundle] pathForResource:@"Battercake" ofType:@"bundle"];
        NSString *databaseFilePath = [bundlePath stringByAppendingPathComponent:@"INTRO.db"];
        
        database = [[FMDatabase alloc] initWithPath:databaseFilePath];
    });
    [database open];
    return database;
}

@end
