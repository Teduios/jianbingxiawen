//
//  ConstellationNetManager.m
//  实战项目20151205
//
//  Created by tarena on 15/12/16.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "ConstellationNetManager.h"
#import "FORStarArray.h"
static AFHTTPSessionManager *manager = nil;
@implementation ConstellationNetManager

+ (AFHTTPSessionManager *)sharedAFManager {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [AFHTTPSessionManager manager];
        manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/html", @"application/json", @"text/json", @"text/javascript", @"text/plain", nil];
        manager.requestSerializer.timeoutInterval = 20;
    });
    return manager;
}

+ (id)getContentWithTag:(NSInteger)tag completionHandle:(void (^)(id, NSError *))completionHandle {
    
    
    NSString *urlStr = FOR_URL;
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"key"] = FOR_APIKEY;
    NSArray *starsArray = [FORStarArray sharedStarArray].allStars;
    parameters[@"consName"] = starsArray[tag];
    if ([FORStarArray sharedStarArray].dateChoosen.length > 0) {
        parameters[@"type"] = [FORStarArray sharedStarArray].dateChoosen;
    } else {
        parameters[@"type"] = @"today";
    }
    
//    return [[self sharedAFManager] GET:urlStr parameters:parameters success:^(NSURLSessionDataTask * _Nonnull task, id  _Nonnull responseObject) {
//        completionHandle(responseObject, nil);
//    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
//        completionHandle(nil, error);
//    }];
    return [[self sharedAFManager] GET:urlStr parameters:parameters progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        completionHandle(responseObject, nil);
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        completionHandle(nil, error);
    }];
}

@end
