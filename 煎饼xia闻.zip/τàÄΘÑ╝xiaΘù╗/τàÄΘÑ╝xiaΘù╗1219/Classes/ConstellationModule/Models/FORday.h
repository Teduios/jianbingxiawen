//
//  FORday.h
//  星座数据获取方法
//
//  Created by tarena on 15/12/4.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FORday : NSObject
@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *QFriend;
@property (strong, nonatomic) NSString *all;
@property (strong, nonatomic) NSString *color;
@property (strong, nonatomic) NSString *datetime;
@property (strong, nonatomic) NSString *health;
@property (strong, nonatomic) NSString *love;
@property (strong, nonatomic) NSString *money;
@property (strong, nonatomic) NSString *work;
@property (assign, nonatomic) NSNumber *number;
@property (strong, nonatomic) NSString *summary;
@property (strong, nonatomic) NSString *resultcode;

@end
