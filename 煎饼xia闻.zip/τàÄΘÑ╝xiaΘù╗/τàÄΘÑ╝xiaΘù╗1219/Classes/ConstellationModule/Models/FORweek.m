//
//  FORweek.m
//  星座数据获取方法
//
//  Created by tarena on 15/12/4.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "FORweek.h"

@implementation FORweek
- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
}
@end
