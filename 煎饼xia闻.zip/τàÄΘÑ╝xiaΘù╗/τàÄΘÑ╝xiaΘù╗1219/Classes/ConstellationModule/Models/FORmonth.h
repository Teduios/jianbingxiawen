//
//  FORmonth.h
//  星座数据获取方法
//
//  Created by tarena on 15/12/4.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FORmonth : NSObject

@property (strong, nonatomic) NSString *date;
@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *all;
@property (strong, nonatomic) NSString *health;
@property (strong, nonatomic) NSString *love;
@property (strong, nonatomic) NSString *money;
@property (strong, nonatomic) NSString *work;
@property (assign, nonatomic) NSNumber *month;
@property (strong, nonatomic) NSString *resultcode;


@end
