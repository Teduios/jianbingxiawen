//
//  FORStarArray.h
//  星座数据获取方法
//
//  Created by tarena on 15/12/6.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FORStarArray : NSObject
@property (strong, nonatomic) NSString *nowDate;
@property (strong, nonatomic) NSArray *allDates;
@property (strong, nonatomic) NSArray *allStars;
@property (strong, nonatomic) NSArray *allDateChooses;
@property (strong, nonatomic) NSArray *allDateChoosesChinese;
@property (strong, nonatomic) NSArray *allImagesPic;
@property (strong, nonatomic) NSString *dateChoosen;
@property (assign, nonatomic) NSInteger tag;

+ (FORStarArray *)sharedStarArray;
@end
