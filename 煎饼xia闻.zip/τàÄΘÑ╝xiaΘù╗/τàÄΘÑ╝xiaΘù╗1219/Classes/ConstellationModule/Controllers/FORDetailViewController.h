//
//  FORDetailViewController.h
//  实战项目20151205
//
//  Created by tarena on 15/12/15.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FORDetailViewController : UIViewController

- (id)initWithDictionary:(NSDictionary *)dictionary;

@end
