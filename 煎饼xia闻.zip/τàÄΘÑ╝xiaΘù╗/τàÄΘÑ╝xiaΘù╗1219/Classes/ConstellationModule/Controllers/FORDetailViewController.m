//
//  FORDetailViewController.m
//  实战项目20151205
//
//  Created by tarena on 15/12/15.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "FORDetailViewController.h"
#import "FORStarArray.h"
#import "FORday.h"
#import "DCPathButton.h"
#import "UIButton+FORButtonAtrri.h"
#import "ConstellationNetManager.h"

#define BLOOM_RADIUS 120.0f
#define  CHOOSER_MOMENT_BUTTON @"chooser-moment-button"
#define  CHOOSER_MOMENT_BUTTON_HIGHLIGHTED @"chooser-moment-button-highlighted"
#define DAY_TIME_BACKGROUNDIMAGE_NAME @"pic36"
#define NIGHT_BACKGROUNDIMAGE_NAME @"pic24"
#define GUIDE_VIEW @"ConsM"


@interface FORDetailViewController ()<UITableViewDataSource, UITableViewDelegate, DCPathButtonDelegate>

@property (strong, nonatomic) NSDictionary *dica;
@property (strong, nonatomic) NSMutableArray *keys;
@property (strong, nonatomic) NSMutableArray *values;

@property (strong, nonatomic) DCPathButton *button;

@property (strong, nonatomic) UITableView *DetaiTableView;

@property (nonatomic, strong) XTGuideViewTool *tool;

@end

@implementation FORDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self loadGuidView];
    
    [self configNavigationItemAndOther];
    
    [self addTableView];
    
    [self analyseData];
    
    [self configChooseDateButton];
    
    [self setUserDefaults];
}

- (void)setUserDefaults {

    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    
    BOOL isfirstOpen = [userDefaults boolForKey:@"isConstellationFirstOpen"];
    
    if (!isfirstOpen) {
        [userDefaults setBool:YES forKey: @"isConstellationFirstOpen"];
    }
}

- (void)loadGuidView {
    XTGuideViewTool *tool = [XTGuideViewTool showGuideView];
    
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:GUIDE_VIEW]];
    if (CURRENT_DEVICE == 4) {
        imageView.frame = CGRectMake(58, 180, 270, 190);
    } else if (CURRENT_DEVICE == 5) {
        imageView.frame = CGRectMake(58, 245, 270, 190);
    } else if (CURRENT_DEVICE == 6) {
        imageView.frame = CGRectMake(85, 320, 300, 200);
    } else {
        imageView.frame = CGRectMake(125, 380, 300, 200);
    }
    
    
    [tool.guideImageView addSubview:imageView];
    self.tool = tool;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self shouldChangeTheme];
}

#pragma mark----ChangeTheme
- (void)shouldChangeTheme {
    BOOL status = [FifthViewController sharedFifthViewController].ThemeSwitchStatus;
    if (status) {
        self.navigationController.navigationBar.barStyle  = UIBarStyleBlack;
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
        self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
        self.DetaiTableView.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed: NIGHT_BACKGROUNDIMAGE_NAME]];
    } else {
        self.navigationController.navigationBar.barStyle  = UIBarStyleDefault;
        self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
        self.DetaiTableView.backgroundView = [[UIImageView alloc] initWithImage:[UIImage imageNamed: DAY_TIME_BACKGROUNDIMAGE_NAME]];
    }
}

#pragma mark-----init
- (id)initWithDictionary:(NSDictionary *)dictionary {
    if (self = [super init]) {
        self.dica = dictionary;
    }
    return self;
}

#pragma mark-----ConfigTableView
- (void)addTableView {
    self.DetaiTableView = [[UITableView alloc] init];
    self.DetaiTableView.backgroundColor = [UIColor colorWithWhite:0.5 alpha:0.2];
    self.DetaiTableView.dataSource = self;
    self.DetaiTableView.delegate = self;
    self.DetaiTableView.estimatedSectionHeaderHeight = 20;
    
    [self.view addSubview:self.DetaiTableView];
    
    [self.DetaiTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
}

#pragma mark--------UITableViewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.keys.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    
    cell.backgroundColor = [UIColor colorWithWhite:0.2 alpha:0.2];
    cell.textLabel.numberOfLines = 0;
    cell.textLabel.text = self.values[indexPath.section];
    cell.textLabel.textColor = [UIColor whiteColor];
    cell.userInteractionEnabled = NO;
    
    return cell;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    UILabel *label = [UILabel new];
    label.backgroundColor = [UIColor clearColor];
    NSString *str = self.keys[section];
    if ([str isEqualToString:@"date"]) {
        label.text = @"日期";
    } else if ([str isEqualToString:@"name"]) {
        label.text = @"星座名称";
    } else if ([str isEqualToString:@"Qfriend"]) {
        label.text = @"星座好友";
    } else if ([str isEqualToString:@"all"]) {
        label.text = @"综合指数";
    } else if ([str isEqualToString:@"color"]) {
        label.text = @"幸运色";
    } else if ([str isEqualToString:@"datetime"]) {
        label.text = @"年月日";
    } else if ([str isEqualToString:@"health"]) {
        label.text = @"健康指数";
    } else if ([str isEqualToString:@"love"]) {
        label.text = @"爱情指数";
    } else if ([str isEqualToString:@"money"]) {
        label.text = @"金钱指数";
    } else if ([str isEqualToString:@"number"]) {
        label.text = @"幸运数字";
    } else if ([str isEqualToString:@"work"]) {
        label.text = @"工作指数";
    } else if ([str isEqualToString:@"summary"]) {
        label.text = @"整体运势";
    } else if ([str isEqualToString:@"weekth"]) {
        label.text = @"周";
    } else if ([str isEqualToString:@"job"]) {
        label.text = @"求职";
    } else if ([str isEqualToString:@"month"]) {
        label.text = @"月份";
    } else if ([str isEqualToString:@"year"]) {
        label.text = @"年号";
    } else if ([str isEqualToString:@"career"]) {
        label.text = @"生涯总结";
    } else if ([str isEqualToString:@"finance"]) {
        label.text = @"财运分析";
    } else if ([str isEqualToString:@"luckyStone"]) {
        label.text = @"幸运宝石";
    }
    label.textColor = [UIColor colorWithRed:17.0/255.0 green:190.0/255.0 blue:227.0/255.0 alpha:1.0];
    label.frame = CGRectMake(0, 0, SCREEN_WIDTH, 20);
    return label;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    NSString *str = self.keys[section];
    if ([str isEqualToString:@"date"]) {
        return @"日期";
    } else if ([str isEqualToString:@"name"]) {
        return @"星座名称";
    } else if ([str isEqualToString:@"Qfriend"]) {
        return @"星座好友";
    } else if ([str isEqualToString:@"all"]) {
        return @"综合指数";
    } else if ([str isEqualToString:@"color"]) {
        return @"幸运色";
    } else if ([str isEqualToString:@"datetime"]) {
        return @"年月日";
    } else if ([str isEqualToString:@"health"]) {
        return @"健康指数";
    } else if ([str isEqualToString:@"love"]) {
        return @"爱情指数";
    } else if ([str isEqualToString:@"money"]) {
        return @"金钱指数";
    } else if ([str isEqualToString:@"number"]) {
        return @"幸运数字";
    } else if ([str isEqualToString:@"work"]) {
        return @"工作指数";
    } else if ([str isEqualToString:@"summary"]) {
        return @"整体运势";
    } else if ([str isEqualToString:@"weekth"]) {
        return @"周";
    } else if ([str isEqualToString:@"job"]) {
        return @"求职";
    } else if ([str isEqualToString:@"month"]) {
        return @"月份";
    } else if ([str isEqualToString:@"year"]) {
        return @"年号";
    } else if ([str isEqualToString:@"career"]) {
        return @"生涯总结";
    } else if ([str isEqualToString:@"finance"]) {
        return @"财运分析";
    } else if ([str isEqualToString:@"luckyStone"]) {
        return @"幸运宝石";
    }
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return UITableViewAutomaticDimension;
}

#pragma mark----监听滚动隐藏按钮方法
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    self.button.hidden = YES;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    self.button.hidden = NO;
}


#pragma mark------AnalyseData
- (void)analyseData {
    self.keys = [NSMutableArray array];
    for (NSString *key in self.dica.allKeys) {
        if ([key isEqualToString:@"resultcode"]||[key isEqualToString:@"error_code"]||[key isEqualToString:@"mima"]||[key isEqualToString:@"QFriend"]||[key isEqualToString:@"future"]){
            
        } else {
            NSString *str = [NSString stringWithFormat:@"%@", self.dica[key]];
            if (str.length != 0) {
                [self.keys addObject:key];
            }
        }
    }
    
    NSArray *newKeys = [self.keys copy];
    newKeys = [newKeys sortedArrayUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        NSComparisonResult result = [obj1 compare:obj2];
        return result == NSOrderedAscending;
    }];
    self.values = [NSMutableArray array];
    NSMutableArray *lastKey = [newKeys mutableCopy];
    for (int i = 0; i < lastKey.count; i++) {
        NSString *key = lastKey[i];
        NSString *value = nil;
        if ([self.dica[key] isKindOfClass:[NSArray class]]) {
            NSArray *array = self.dica[key];
            if (array.count == 1) {
                value = [NSString stringWithFormat:@"%@", self.dica[key][0]];
                [self.values addObject:value];
            } else {
                [lastKey removeObject:key];
            }
        } else {
            key = lastKey[i];
            value = [NSString stringWithFormat:@"%@", self.dica[key]];
            [self.values addObject:value];
        }
    }
    [self.keys removeAllObjects];
    self.keys = [lastKey mutableCopy];
}

#pragma mark------ConfigNavigationAndOther
- (void)configNavigationItemAndOther {
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    NSInteger tag = [FORStarArray sharedStarArray].tag;
    self.navigationItem.title = [FORStarArray sharedStarArray].allStars[tag];
}

#pragma mark----ConfigChoseDateButton
- (void)configChooseDateButton {
    
    self.button = [[DCPathButton alloc] initWithCenterImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON]
                                           highlightedImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON_HIGHLIGHTED]];
    DCPathItemButton *firstItemButton = [[DCPathItemButton alloc] initWithImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON]
                                                               highlightedImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON_HIGHLIGHTED]
                                                                backgroundImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON]
                                                     backgroundHighlightedImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON_HIGHLIGHTED]];
    
    DCPathItemButton *secondItemButton = [[DCPathItemButton alloc] initWithImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON]
                                                                highlightedImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON_HIGHLIGHTED]
                                                                 backgroundImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON]
                                                      backgroundHighlightedImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON_HIGHLIGHTED]];
    
    DCPathItemButton *thirdItemButton = [[DCPathItemButton alloc] initWithImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON]
                                                               highlightedImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON_HIGHLIGHTED]
                                                                backgroundImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON]
                                                     backgroundHighlightedImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON_HIGHLIGHTED]];
    
    DCPathItemButton *fourthItemButton = [[DCPathItemButton alloc] initWithImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON]
                                                                highlightedImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON_HIGHLIGHTED]
                                                                 backgroundImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON]
                                                      backgroundHighlightedImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON_HIGHLIGHTED]];
    
    DCPathItemButton *fifthItemButton = [[DCPathItemButton alloc] initWithImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON]
                                                               highlightedImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON_HIGHLIGHTED]
                                                                backgroundImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON]
                                                     backgroundHighlightedImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON_HIGHLIGHTED]];
    [firstItemButton setButtonWithTitle:@"年" withTitleColor:[UIColor blueColor] setBackgroudImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON] forState:UIControlStateNormal];
    
    [secondItemButton setButtonWithTitle:@"月" withTitleColor:[UIColor blueColor] setBackgroudImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON] forState:UIControlStateNormal];
    
    [thirdItemButton setButtonWithTitle:@"周" withTitleColor:[UIColor blueColor] setBackgroudImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON] forState:UIControlStateNormal];
    
    [fourthItemButton setButtonWithTitle:@"明" withTitleColor:[UIColor blueColor] setBackgroudImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON] forState:UIControlStateNormal];
    
    [fifthItemButton setButtonWithTitle:@"今" withTitleColor:[UIColor blueColor] setBackgroudImage:[UIImage imageNamed:CHOOSER_MOMENT_BUTTON] forState:UIControlStateNormal];
    
    [self.button addPathItems:@[firstItemButton, secondItemButton, thirdItemButton, fourthItemButton, fifthItemButton]];
    self.button.bloomRadius = BLOOM_RADIUS;
    self.button.delegate = self;
    self.button.allowCenterButtonRotation = NO;
    self.button.bottomViewColor  = [UIColor grayColor];
    self.button.bloomDirection = kDCPathButtonBloomDirectionLeft;
    if (CURRENT_DEVICE == 4) {
        self.button.dcButtonCenter = CGPointMake(SCREEN_WIDTH - 30, SCREEN_HEIGHT - 140);
    } else if (CURRENT_DEVICE == 5) {
        self.button.dcButtonCenter = CGPointMake(SCREEN_WIDTH - 32, SCREEN_HEIGHT - 160);
    } else {
        self.button.dcButtonCenter = CGPointMake(SCREEN_WIDTH - 32, SCREEN_HEIGHT - 180);
    }
    
    self.view.userInteractionEnabled = YES;
    [self.view addSubview:self.button];
}

#pragma mark-----DCPathButtonDelegate
- (void)pathButton:(DCPathButton *)dcPathButton clickItemButtonAtIndex:(NSUInteger)itemButtonIndex {
    
    [MBProgressHUD showSuccess:@"正在加载请稍后"];
    
    NSArray *time = [FORStarArray sharedStarArray].allDateChooses;
    [FORStarArray sharedStarArray].dateChoosen = time[itemButtonIndex];
    NSInteger tag = [FORStarArray sharedStarArray].tag;
    __weak typeof(self) wself = self;
    [ConstellationNetManager getContentWithTag:tag completionHandle:^(id content, NSError *error) {
        if (!error) {
        if ([content[@"resultcode"] isEqualToString:@"202"]) {
            [MBProgressHUD showError:@"服务器有问题，请重试"];
        } else {
            wself.dica = content;
            [self analyseData];
            [wself.DetaiTableView reloadData];
        }
        } else {
            [MBProgressHUD showError:@"网络错误，请重试"];
        }
    }];
}

@end
