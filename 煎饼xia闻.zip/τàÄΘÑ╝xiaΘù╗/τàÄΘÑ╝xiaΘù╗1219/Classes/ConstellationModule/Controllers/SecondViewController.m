//
//  ViewController.m
//  星座数据获取方法
//
//  Created by tarena on 15/12/4.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "SecondViewController.h"
#import "FORSubView.h"
#import "FORStarArray.h"
#import "FORDetailViewController.h"
#import "FifthViewController.h"

#define DAY_TIME_BACKGROUNDIMAGE_NAME @"pic36"
#define NIGHT_BACKGROUNDIMAGE_NAME @"pic24"

@interface SecondViewController ()<FORSubViewDelegate>

@property (strong, nonatomic) UIImageView *backgoundImageView;

@end

@implementation SecondViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setBackgroudImage];
    
    [self addSubView];
    
}
- (void)setBackgroudImage {
    self.navigationItem.title = @"星座";
    
    
    self.backgoundImageView = [UIImageView new];
    [self.view addSubview:self.backgoundImageView];
    [_backgoundImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self shouldChangeTheme];
}

#pragma mark----ChangeTheme
- (void)shouldChangeTheme {
    BOOL status = [FifthViewController sharedFifthViewController].ThemeSwitchStatus;
    
    if (status) {
        self.navigationController.navigationBar.barStyle  = UIBarStyleBlack;
        self.navigationController.navigationBar.barTintColor = [UIColor blackColor];
        self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
        self.backgoundImageView.image = [UIImage imageNamed:NIGHT_BACKGROUNDIMAGE_NAME];
    } else {
        self.navigationController.navigationBar.barStyle  = UIBarStyleDefault;
        self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
        self.backgoundImageView.image = [UIImage imageNamed:DAY_TIME_BACKGROUNDIMAGE_NAME];
    }
   
}
- (void)addSubView {
    FORSubView * subView = [FORSubView getSubViewWithFrame:self.view.bounds];
    subView.delegate = self;
    [self.view addSubview:subView];
}
- (void)fORSubView:(FORSubView *)subView sendDictionary:(NSDictionary *)dictionary {
    
    if ([dictionary[@"resultcode"] isEqualToString:@"202"]) {
        [MBProgressHUD showError:@"网络问题,请重试"];
        return;
    }
    FORDetailViewController *detailController = [[FORDetailViewController alloc] initWithDictionary:dictionary];
    [self.navigationController pushViewController:detailController animated:YES];    
}

@end
