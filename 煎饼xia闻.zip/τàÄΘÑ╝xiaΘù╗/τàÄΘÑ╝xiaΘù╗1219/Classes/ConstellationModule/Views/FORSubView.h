//
//  FORSubView.h
//  星座数据获取方法
//
//  Created by tarena on 15/12/6.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^Info) (NSDictionary *dic);

@class FORSubView;
@protocol  FORSubViewDelegate<NSObject>

- (void)fORSubView:(FORSubView *)subView  sendDictionary:(NSDictionary *)dictionary;

@end

@interface FORSubView : UIView

@property (weak, nonatomic) id<FORSubViewDelegate> delegate;

+ (FORSubView *)getSubViewWithFrame:(CGRect)frame;

@end
