//
//  FORSubView.m
//  星座数据获取方法
//
//  Created by tarena on 15/12/6.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "FORSubView.h"
#import "FORMetaDataTool.h"
#import "FORStarArray.h"
#import "ConstellationNetManager.h"
@interface FORSubView ()

@end

@implementation FORSubView

+ (FORSubView *)getSubViewWithFrame:(CGRect)frame {
    
    FORSubView *subView = [[FORSubView alloc] initWithFrame:frame];
    
    
    [subView addButton];
    return subView;
}

- (void)addButton {
    self.backgroundColor = [UIColor clearColor];
    NSArray *keys = [FORStarArray sharedStarArray].allStars;
    UIView *superView = [UIView new];
    [self addSubview:superView];
    __weak typeof(self) wself = self;
    CGFloat topDistance;
    switch (CURRENT_DEVICE) {
        case 4:
            topDistance = 120;
            break;
        case 5:
            topDistance = 160;
            break;
        case 6:
            topDistance = 180;
            break;
        case 7:
            topDistance = 200;
            break;
            
        default:
            topDistance = 180;
            break;
    }
    [superView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(wself).with.insets(UIEdgeInsetsMake(topDistance, 50, 50, 50));
    }];
    for (int i = 1; i <= keys.count; i++) {
        
        NSString *key = keys[i - 1];

        int rowNum = i % 3 == 0 ? i / 3 : i / 3 + 1;
        int colNum = i % 3;
        
        UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
        UILabel *label = [UILabel new];
        [superView addSubview:button];
        [superView addSubview:label];
        

        __block  CGFloat factor = 0.0;
        switch (CURRENT_DEVICE) {
            case 4:
                factor = 0.105f;
                button.titleLabel.font = [UIFont boldSystemFontOfSize:14];
                button.contentEdgeInsets = UIEdgeInsetsMake(17, 0, 0, 0);
                label.font = [UIFont boldSystemFontOfSize:10];
                break;
            case 5:
                factor = 0.105f;
                button.titleLabel.font = [UIFont boldSystemFontOfSize:14];
                button.contentEdgeInsets = UIEdgeInsetsMake(22, 0, 0, 0);
                label.font = [UIFont boldSystemFontOfSize:11];
                break;
            case 6:
                factor = 0.11f;
                button.titleLabel.font = [UIFont boldSystemFontOfSize:16];
                button.contentEdgeInsets = UIEdgeInsetsMake(27, 0, 0, 0);
                label.font = [UIFont boldSystemFontOfSize:13];
                break;
            case 7:
                factor = 0.115f;
                button.titleLabel.font = [UIFont boldSystemFontOfSize:18];
                button.contentEdgeInsets = UIEdgeInsetsMake(32, 0, 0, 0);
                label.font = [UIFont boldSystemFontOfSize:14];
                break;
            default:
                factor = 0.10f;
                break;
        }
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(button.mas_bottom);
            make.left.equalTo(button.mas_left).with.offset(-10);
            make.right.equalTo(button.mas_right).with.offset(10);
            make.height.equalTo(@20);
        }];
        [button setTitle:key forState:UIControlStateNormal];
        button.titleLabel.numberOfLines = 0;
        button.tag = i;
        
        NSString *imageName = [FORStarArray sharedStarArray].allImagesPic[i - 1];
        [button setBackgroundImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
        button.showsTouchWhenHighlighted = YES;
        
        label.textAlignment = NSTextAlignmentCenter;
        label.textColor = [UIColor whiteColor];
        label.text = [FORStarArray sharedStarArray].allDates[i - 1];

        [button addTarget:self action:@selector(clickStarButton:) forControlEvents:UIControlEventTouchUpInside];

            factor = 0.25f;
        
        [button mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.equalTo(superView.mas_width).with.multipliedBy(factor);
            
            switch (rowNum) {
                case 1:
                    make.baseline.equalTo(superView.mas_baseline).with.multipliedBy(0.01);
                    break;
                case 2:
                    make.baseline.equalTo(superView.mas_baseline).with.multipliedBy(0.26);
                    break;
                case 3:
                    make.baseline.equalTo(superView.mas_baseline).with.multipliedBy(0.51);
                    break;
                case 4:
                    make.baseline.equalTo(superView.mas_baseline).with.multipliedBy(0.76);
                    break;
                default:
                    break;
            }
            switch (colNum) {
                case 0:
                    make.right.equalTo(superView.mas_right).with.offset(10);
                    break;
                case 1:
                    make.left.equalTo(superView.mas_left).with.offset(-10);
                    break;
                case 2:
                    make.centerX.equalTo(superView.mas_centerX);
                    break;
                default:
                    break;
            }
        }];
    }
}

- (void)clickStarButton:(UIButton *)btn {
    self.userInteractionEnabled = NO;
    
    [MBProgressHUD showSuccess:@"正在加载请稍后"];
    [FORStarArray sharedStarArray].tag = btn.tag - 1;
    __weak typeof(self) wself = self;
    [ConstellationNetManager getContentWithTag:(btn.tag - 1) completionHandle:^(id content, NSError *error) {
        wself.userInteractionEnabled = YES;
        if (!error) {
            [wself.delegate fORSubView:wself  sendDictionary:content];
        } else {
            [MBProgressHUD showError:@"网络错误，请重试"];
        }
    }];
    
}


@end
