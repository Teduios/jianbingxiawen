//
//  UIButton+FORButtonAtrri.m
//  星座数据获取方法
//
//  Created by tarena on 15/12/9.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "UIButton+FORButtonAtrri.h"

@implementation UIButton (FORButtonAtrri)

- (void)setButtonWithTitle:(NSString *)title withTitleColor:(UIColor *)color setBackgroudImage:(UIImage *)image forState:(UIControlState)state {
    [self setTitle:title forState:state];
    [self setBackgroundImage:image forState:state];
    [self setTitleColor:color forState:state];
}

@end
