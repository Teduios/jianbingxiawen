//
//  FORMetaDataTool.m
//  星座数据获取方法
//
//  Created by tarena on 15/12/5.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import "FORMetaDataTool.h"

@implementation FORMetaDataTool
static FORday *day = nil;
+ (FORday *)parseDayWithDic:(NSDictionary *)dayDic {
    if (day == nil) {
        day = [[self alloc] getAndParseWithDic:dayDic withClass:[FORday class]];
    }
    return day;
}

static FORweek *week = nil;
+ (FORweek *)parseWeekWithDic:(NSDictionary *)weekDic {
    if (week == nil) {
        week = [[self alloc] getAndParseWithDic:weekDic withClass:[FORweek class]];
    }
    return week;
}

static FORmonth *month = nil;
+ (FORmonth *)parseMonthWithDic:(NSDictionary *)monthDic {
    if (month == nil) {
        month = [[self alloc] getAndParseWithDic:monthDic withClass:[FORmonth class]];
    }
    return month;
}


- (id)getAndParseWithDic:(NSDictionary *)dic  withClass:(Class) className {
    id instance = [[className alloc] init];
    [instance setValuesForKeysWithDictionary:dic];
    return instance;
}

static FORyear *year = nil;
+ (FORyear *)parseYearWithDic:(NSDictionary *)yearDic {
    if (year == nil) {
        year = [[self alloc] getAndParseWithDic:yearDic withClass:[FORyear class]];
    }
    return year;
}

- (id)getYearWithDic:(NSDictionary *)yearDic {
    FORyear *year = [[FORyear alloc] init];
    year.date = yearDic[@"date"];
    year.name = yearDic[@"name"];
    year.health = yearDic[@"health"][0];
    year.love = yearDic[@"love"][0];
    year.year = yearDic[@"year"];
    year.info = yearDic[@"mima"][@"info"];
    year.text = yearDic[@"mima"][@"text"][0];
    year.career = yearDic[@"career"][0];
    year.finance = yearDic[@"finance"][0];
    return year;
}
@end
