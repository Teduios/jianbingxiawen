//
//  FORMetaDataTool.h
//  星座数据获取方法
//
//  Created by tarena on 15/12/5.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FORday.h"
#import "FORweek.h"
#import "FORmonth.h"
#import "FORyear.h"
@interface FORMetaDataTool : NSObject

+ (FORday *)parseDayWithDic:(NSDictionary *)dayDic;
+ (FORweek *)parseWeekWithDic:(NSDictionary *)weekDic;
+ (FORmonth *)parseMonthWithDic:(NSDictionary *)monthDic;
+ (FORyear *)parseYearWithDic:(NSDictionary *)yearDic;

@end
