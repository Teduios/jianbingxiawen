//
//  UIImage+XTTintColor.h
//  实战项目20151205
//
//  Created by tarena on 15/12/11.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (XTTintColor)

- (UIImage *) imageWithTintColor:(UIColor *)tintColor;

@end
