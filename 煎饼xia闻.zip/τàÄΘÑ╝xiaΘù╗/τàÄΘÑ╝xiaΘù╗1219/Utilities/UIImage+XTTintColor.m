//
//  UIImage+XTTintColor.m
//  实战项目20151205
//
//  Created by tarena on 15/12/11.
//  Copyright © 2015年 Shaw. All rights reserved.
//

#import "UIImage+XTTintColor.h"

@implementation UIImage (XTTintColor)

- (UIImage *) imageWithTintColor:(UIColor *)tintColor
{
 
    UIGraphicsBeginImageContextWithOptions(self.size, NO, 0.0f);
    [tintColor setFill];
    CGRect bounds = CGRectMake(0, 0, self.size.width, self.size.height);
    UIRectFill(bounds);
   
    [self drawInRect:bounds blendMode:kCGBlendModeDestinationIn alpha:1.0f];
    
    UIImage *tintedImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return tintedImage;
}

@end
